package PageRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

	// 1.Declare
	@FindBy(id = "login-button")
	private WebElement loginbutton;

	// 2.Initilization
	public LoginPage(WebDriver driver) 
	{
		PageFactory.initElements(driver, this);
	}

	
	
	
	//3.Utilization
	public WebElement getloginbutton() {
		return loginbutton;
	}
	
	
	
	
	
	
	
	
}
