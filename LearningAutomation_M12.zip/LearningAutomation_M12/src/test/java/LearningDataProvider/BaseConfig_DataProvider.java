package LearningDataProvider;

import org.testng.annotations.DataProvider;

public class BaseConfig_DataProvider

{
	@DataProvider
	public Object[][] loginData() {

		Object[][] data = new Object[3][3];

		data[0][0] = "standard_user";
		data[0][1] = "secret_sauce";
		data[0][2] = "Selenium_M11";

		data[1][0] = "problem_user";
		data[1][1] = "secret_sauce";
		data[1][2] = "Selenium_M12";

		data[2][0] = "visual_user";
		data[2][1] = "secret_sauce";
		data[2][2] = "Selenium_M13";

		return data;

	}

}
