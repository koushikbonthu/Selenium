package LearningDataProvider;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class Task1  extends BaseConfig_DataProvider{
	
	
	
	@Test(dataProvider = "loginData")
	public void performLogin(String username,String password,String batchcode) 
	{
		
		Reporter.log(username,true);
		Reporter.log(password,true);
		Reporter.log(batchcode,true);
		System.out.println("------------------------");
		
	}

}
