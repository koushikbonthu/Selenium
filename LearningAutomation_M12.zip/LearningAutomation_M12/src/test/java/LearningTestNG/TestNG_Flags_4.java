package LearningTestNG;

import org.testng.annotations.Test;

public class TestNG_Flags_4 {

	@Test(enabled = true)
	public void m1() {
		System.out.println("m1");

	}

	@Test(enabled = false)
	public void m2() {
		System.out.println("m2");

	}
}
