package LearningTestNG;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class TestNG_Flags_2 {

	@Test(dependsOnMethods = "Apple")
	public void Banana() {
		Reporter.log("Banana", true);
		

	}

	@Test(dependsOnMethods = "Banana")
	public void Apple() {
		Reporter.log("Apple", true);
		//Assert.fail();

	}

}
