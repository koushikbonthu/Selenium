package LearningTestNG;


import org.testng.Reporter;
import org.testng.annotations.Test;

public class Task2 extends BaseConfiguration 
{
	@Test
	public void m2() {
		Reporter.log("m2",true);
	}

}
