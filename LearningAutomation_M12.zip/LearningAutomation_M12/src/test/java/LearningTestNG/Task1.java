package LearningTestNG;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class Task1 extends BaseConfiguration {

	@Test(enabled = false)
	public void m1() {

		Reporter.log("m1", true);

		// Assert.fail();
	}

	@Test(groups = {"RT","FT"})
	public void G1() {
		Reporter.log("G1", true);

	}

	@Test(groups = {"IT","RT"})
	public void G2() {
		Reporter.log("G2", true);

	}

	@Test(groups = { "FT","RT"})
	public void G3() {
		Reporter.log("G3", true);

	}

	@Test(groups = {"ST","RT"})
	public void G4() {
		Reporter.log("G4", true);

	}

	@Test(groups = {"FT","RT"})
	public void G5() {
		Reporter.log("G5", true);

	}

}
