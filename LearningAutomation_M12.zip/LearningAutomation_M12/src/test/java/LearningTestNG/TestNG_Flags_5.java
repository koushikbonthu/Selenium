package LearningTestNG;

import org.testng.annotations.Test;

public class TestNG_Flags_5 {

	@Test(enabled = true,priority = 1,groups = "FT")
	public void m1() {
		System.out.println("m1");

	}

	@Test(enabled = false)
	public void m2() {
		System.out.println("m2");

	}
}
