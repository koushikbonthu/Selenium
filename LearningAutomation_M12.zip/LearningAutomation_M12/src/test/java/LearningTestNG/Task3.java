package LearningTestNG;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class Task3 extends BaseConfiguration {

	@Test
	public void m3() {
		Reporter.log("m3", true);

	}
}
