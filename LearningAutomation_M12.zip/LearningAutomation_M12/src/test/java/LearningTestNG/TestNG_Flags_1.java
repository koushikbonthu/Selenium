package LearningTestNG;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class TestNG_Flags_1 {
	
	
	@Test(priority = -1)
	public void m1() {
		System.out.println("m1");
		
	}
	
	
	@Test(priority = 2)
	public void m2() {
		System.out.println("m2");
		
	}
	
	
	@Test(priority = -3)
	public void m3() {
		System.out.println("m3");
		
	}


}
