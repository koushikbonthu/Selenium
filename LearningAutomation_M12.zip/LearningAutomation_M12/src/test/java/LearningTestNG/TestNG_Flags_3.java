package LearningTestNG;

import org.testng.annotations.Test;

public class TestNG_Flags_3 {
	
	
	@Test(invocationCount = 5)
	public void m1() {
		System.out.println("m1");
		
	}
}
