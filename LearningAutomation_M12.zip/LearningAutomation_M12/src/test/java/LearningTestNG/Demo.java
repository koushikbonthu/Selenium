package LearningTestNG;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Demo extends BaseConfiguration {

	@Test
	public void AddProduct() {
		Reporter.log("Added nth product", true);

		// Perform Assertion Using Hard Assert

		// Assert.fail();

		Assert.assertEquals("Selenium", "Selenium");

		Assert.assertEquals(true, true);

		Assert.assertEquals(10, 10);

		Assert.assertNotEquals("Selenium", "Java");

		Assert.assertNotEquals(true, false);

		Assert.assertNotEquals(10, 11);

		Assert.assertTrue(true);

		Assert.assertFalse(false);

		// Perform Assertion Using Soft Assert

		SoftAssert sobj = new SoftAssert();

		sobj.assertEquals("SELENIUM", "SELENIUM");

		sobj.assertNotEquals("SELENIUM", "JAVA");

		sobj.assertTrue(true);

		sobj.assertFalse(false);

		sobj.assertAll();

		System.out.println("Demo Execution Completed..!");

	}

}
