package LearningSynchronization;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HandlingSynchronization {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = new ChromeDriver();

		// Selenium-Wait Statement-1
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30l));

		driver.get("https://www.shoppersstack.com/");

		// Java-wait Statement
		// Thread.sleep(10000);

		// Selenium-Wait Statement-2
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30l));

		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='loginBtn']")));
		driver.findElement(By.xpath("//button[@id='loginBtn']")).click();

	}

}
