package LearningPropertiesFile;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import org.testng.annotations.Test;

public class HandlingPropertiesFile {

	@Test
	public void readData() throws IOException {

		// 1.
		FileInputStream fis = new FileInputStream("./src/test/resources/CommonData.properties");

		// 2.
		Properties propertyobj = new Properties();

		// 3.
		propertyobj.load(fis);

		// 4.
		String data1 = propertyobj.getProperty("usernamejkjh");
		String data2 = propertyobj.getProperty("password");
		String data3 = propertyobj.getProperty("url");

		System.out.println(data1);
		System.out.println(data2);
		System.out.println(data3);

	}

	@Test
	public void writedata() throws IOException {
		// 1.
		FileInputStream fis = new FileInputStream("./src/test/resources/CommonData.properties");

		// 2.
		Properties propertyobj = new Properties();

		// 3.
		propertyobj.load(fis);

		// 4.
		propertyobj.put("batchcode", "Selenium_M13");

		// 5.
		FileOutputStream fos = new FileOutputStream("./src/test/resources/CommonData.properties");

		// 6.
		propertyobj.store(fos, "New Updates ....!!!!!!!!!!");

		System.out.println("Execution Completed");
	}

}
