package LearningWebElementMethod;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ValidationMethods2 {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = new ChromeDriver();

		driver.get("https://www.tutorialspoint.com/selenium/practice/radio-button.php");

		// Identify
		WebElement element = driver.findElement(By.xpath("//label[text()='Yes']/preceding-sibling::input"));

		// Validation
		boolean res1 = element.isDisplayed();
		boolean res2 = element.isEnabled();
		boolean res3 = element.isSelected();

		System.out.println("Displayed Status: " + res1);
		System.out.println("Enabled Status: " + res2);
		System.out.println("Selected Status: " + res3);
//-----------------------------------------------------------------
		System.out.println("-----------------------");

		Thread.sleep(5000);
		// Perform Action
		element.click();
		Thread.sleep(5000);

		boolean res4 = element.isSelected();
		System.out.println("Selected Status: " + res4);

		driver.close();

	}

}
