package LearningWebElementMethod;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class PeformActionMethods {

	public static void main(String[] args) {

		WebDriver driver = new ChromeDriver();

		driver.get("https://www.tutorialspoint.com/selenium/practice/login.php");

		// Identify the Element
		WebElement email_txtfield = driver.findElement(By.id("email"));
		WebElement password_txtfield = driver.findElement(By.xpath("//input[@id='password']"));
		WebElement login_button = driver.findElement(By.cssSelector("input[value='Login']"));

		// Validation

		// Perform Action
		email_txtfield.sendKeys("harry@gmail.com");

		email_txtfield.clear();

		email_txtfield.sendKeys("seleniumtrainer@gmail.com");

		password_txtfield.sendKeys("Selenium@M12");

		// login_button.click();

		login_button.submit();

	}

}
