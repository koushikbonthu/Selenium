package LearningWebElementMethod;

import org.jspecify.annotations.Nullable;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FetchPropertyMethods {

	public static void main(String[] args) {

		WebDriver driver = new ChromeDriver();

		driver.get("https://demowebshop.tricentis.com/");

		WebElement element = driver.findElement(By.partialLinkText("Regi"));

		// 1.Fetch Text value
		String textvalue = element.getText();

		// 2.Fetch Attribute value---id
		@Nullable
		String id_value = element.getAttribute("id");

		// 3.Fetch TagName
		String tagname = element.getTagName();

		// 4.Fetch Css Value---color
		String cssvalue = element.getCssValue("color");

		// 5.Fetch The Size---Width and Height
		Dimension size = element.getSize();
		int size_width = element.getSize().getWidth();
		int size_height = element.getSize().getHeight();

		// 6.Fetch the Location--X and Y Points
		Point location = element.getLocation();
		int location_x = element.getLocation().getX();
		int location_y = element.getLocation().getY();

	}

}
