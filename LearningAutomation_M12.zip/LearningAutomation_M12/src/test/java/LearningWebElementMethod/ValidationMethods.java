package LearningWebElementMethod;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ValidationMethods {

	public static void main(String[] args)

	{

		WebDriver driver = new ChromeDriver();

		driver.get("https://www.saucedemo.com/");

		// Identify the Elemnts And Store it
		WebElement username_textfield = driver.findElement(By.id("user-name"));
		WebElement password_textfield = driver.findElement(By.id("password"));
		WebElement login_button = driver.findElement(By.id("login-button"));

		// Call The Validation Methods
		boolean res1 = username_textfield.isDisplayed();
		boolean res2 = password_textfield.isDisplayed();
		boolean res3 = login_button.isDisplayed();

		// Perform Validation
		if (res1) {
			System.out.println("Element 1:Verified, It is Displayed  and Status: " + res1);
		} else {
			System.out.println("Element 1:Verified, It is not Displayed  and Status: " + res1);

		}

		if (res2) {
			System.out.println("Element 2:Verified, It is Displayed  and Status: " + res2);
		} else {
			System.out.println("Element 2:Verified, It is not Displayed  and Status: " + res2);

		}

		if (res3) {
			System.out.println("Element 3:Verified, It is Displayed  and Status: " + res3);
		} else {
			System.out.println("Element 3:Verified, It is not Displayed  and Status: " + res3);

		}

		driver.quit();

	}

}
