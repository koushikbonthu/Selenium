package LearningExcelFile;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.testng.annotations.Test;

public class HandlingExcelFile {

	@Test(enabled = false)
	public void readData() throws EncryptedDocumentException, IOException {

		// 1.
		FileInputStream fis = new FileInputStream("./src/test/resources/DemowebShop.xlsx");

		// Create an Workbook
		Workbook book = WorkbookFactory.create(fis);

		// 2.
		Sheet sheet = book.getSheet("RegisterDetails");

		// 3.
		Row row = sheet.getRow(1);

		// 4.
		Cell column = row.getCell(2);

		// 5
		// String data = column.getStringCellValue();

		// Optimized Code
		String data = book.getSheet("RegisterDetails").getRow(1).getCell(2).getStringCellValue();

		System.out.println(data);

		// Fetch the Last Cell Num
		int lastcellnum = book.getSheet("RegisterDetails").getRow(3).getLastCellNum();
		System.out.println(lastcellnum);

		// Print the one Specific row---3rd Row
		for (int i = 0; i < lastcellnum; i++) {

			String datas = book.getSheet("RegisterDetails").getRow(3).getCell(i).getStringCellValue();

			System.out.println(datas);

		}

		// Fetch Last Row Num
		int lastrownum = book.getSheet("RegisterDetails").getLastRowNum();
		System.out.println(lastrownum);

		// print the one specific Column---3rd column
		for (int i = 1; i <= lastrownum; i++) {

			String datas = book.getSheet("RegisterDetails").getRow(i).getCell(4).getStringCellValue();
			System.out.println(datas);
		}

	}

	@Test
	public void writedata() throws EncryptedDocumentException, IOException {
		// 1.
		FileInputStream fis = new FileInputStream("./src/test/resources/DemowebShop.xlsx");

		// 2. Create an Workbook
		Workbook book = WorkbookFactory.create(fis);

		// 3.write the Data in New Sheet,New row,New Cell/column
		// book.createSheet("SeleniumBatchM12").createRow(10).createCell(10).setCellValue("Harry");

		// 3.Update the Data in Existing Sheet, row, New Cell/column
		book.getSheet("RegisterDetails").getRow(9).createCell(1).setCellValue("prasana");

		// 4.Convert java data into Physical File
		FileOutputStream fos = new FileOutputStream("./src/test/resources/DemowebShop.xlsx");

		// 5.write the data
		book.write(fos);

		// 6.close the workBook
		book.close();

		System.out.println("Data Updated in Excel Success");

	}

}
