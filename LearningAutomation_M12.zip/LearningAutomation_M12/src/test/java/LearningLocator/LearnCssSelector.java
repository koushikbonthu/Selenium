package LearningLocator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnCssSelector {

	public static void main(String[] args) {

		WebDriver driver = new ChromeDriver();

		driver.get("https://www.saucedemo.com/");

		driver.findElement(By.cssSelector("#user-name")).sendKeys("standard_user");

		driver.findElement(By.cssSelector("input[name='password']")).sendKeys("secret_sauce");

		driver.findElement(By.cssSelector(".btn_action")).click();
		
		
		
		
		System.out.println("Execution Done By: ");

	}

}
