package LearningLocator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnXpath_Relative {

	public static void main(String[] args) {

		String username = "standard_user";
		String password = "secret_sauce";
		String Authorname = "Harry";

		WebDriver driver = new ChromeDriver();

		driver.get("https://www.saucedemo.com/");

		driver.findElement(By.xpath("//input[contains(@name,'user')]")).sendKeys(username);

		driver.findElement(By.xpath("//input[contains(@id,'pass')]")).sendKeys(password);

		driver.findElement(By.xpath("//input[contains(@class,'submit')]")).click();

		System.out.println("Execution Done By: " + Authorname);

		driver.close();
	}

}
