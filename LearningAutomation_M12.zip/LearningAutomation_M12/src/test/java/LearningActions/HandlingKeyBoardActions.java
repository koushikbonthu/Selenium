package LearningActions;

import java.awt.RenderingHints.Key;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingKeyBoardActions {

	public static void main(String[] args) {

		WebDriver driver = new ChromeDriver();

		driver.get("https://www.saucedemo.com/");

		// 1.create an Instance for Actions Class
		Actions actionobj = new Actions(driver);

		// 2.Call the Non Static method, To perform Specific Actions

		actionobj.sendKeys(Keys.TAB, "standard_user", Keys.TAB, "secret_sauce", Keys.ENTER).perform();

//-------------------------------------------------------

		driver.get("https://www.google.in/");

		actionobj.sendKeys("Harry", Keys.ENTER).perform();
//----------------------------------------------------------
		driver.get("https://demowebshop.tricentis.com/");

		actionobj.sendKeys(Keys.TAB, Keys.TAB, Keys.ENTER).perform();

	}

}
