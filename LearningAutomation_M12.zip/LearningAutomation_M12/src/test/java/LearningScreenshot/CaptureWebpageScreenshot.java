package LearningScreenshot;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class CaptureWebpageScreenshot {

	public static void main(String[] args) throws IOException {

		WebDriver driver = new ChromeDriver();

		driver.get("https://pistahouse.in/");

		// Capture the Screenshot

		// 1.Perform Typecasting from Webdriver to TakesScreenshot.
		TakesScreenshot ts = (TakesScreenshot) driver;

		// 2.Call the Screenshot Method-getScreenshotAs
		
		// 3.Store Screenshot  in Temp Path
		File temp_path = ts.getScreenshotAs(OutputType.FILE);

		// 4.Create a New Permanent Path for the screenshot
		File permanent_path = new File("./Screenshot/MyFirstScreenshot.png");

		// 5.Copy The Screenshot From Temp To Permanent Place
		FileHandler.copy(temp_path, permanent_path);
		
		
		driver.quit();

	}

}
