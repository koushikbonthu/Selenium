package LearningScreenshot;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.io.FileHandler;

public class CaptureWebElementScreenshot {

	public static void main(String[] args) throws IOException {

		WebDriver driver = new ChromeDriver();

		driver.get("https://www.saucedemo.com/");

		// Capture the WebElement Screenshot

		// 1.Identify the Element
		WebElement element = driver.findElement(By.id("login-button"));

		// 2.Call the Screenshot Method
		// 3.Store Screenshot in Temp Path
		File temp_path = element.getScreenshotAs(OutputType.FILE);

		// 4.Create a New Permanent Path for the screenshot
		File permanent_path = new File("./Screenshot/MySecondScreenshot.png");

		// 5.Copy The Screenshot From Temp To Permanent Place
		FileHandler.copy(temp_path, permanent_path);

		driver.quit();
		
		
		System.out.println("Execution Completed...!!");

	}

}
