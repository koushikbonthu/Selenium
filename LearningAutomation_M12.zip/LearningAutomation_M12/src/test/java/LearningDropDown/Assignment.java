package LearningDropDown;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();

		driver.get(
				"file:///C:/Users/Harry/eclipse-workspace-Selenium/LearningAutomation_M12/src/main/resources/EmbededWebpage%20(3).html");
	}
}
