package LearningDropDown;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingDropDown {

	public static void main(String[] args) {

		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.get("https://www.amazon.in/");

		// Handling The Dropdown ---

		// 1.Identify the Dropdown
		WebElement allcategory_dropdown = driver.findElement(By.id("searchDropdownBox"));

		// 2.Craete an Instance For DropDown
		Select selectobj = new Select(allcategory_dropdown);

		// 3.Call the nonstatic methods to Perform Action on Drpdwn

		// 3.1 verify Dropdown
		boolean res = selectobj.isMultiple();
		if (res) {

			System.out.println("Dropdown is Multiple Select");
		} else {
			System.out.println("Dropdown is Single Select");
		}
		// 3.2---Select an Option-----By Using Index
		selectobj.selectByIndex(1);

		selectobj.selectByIndex(10);

		// 3.2---Select an Option-----By Using Visible text
		selectobj.selectByVisibleText("Software");

		selectobj.selectByVisibleText("Video Games");
		
		//3.3---Select an Option-----By Using Value  ATtribute

		selectobj.selectByValue("search-alias=pets");

		selectobj.selectByValue("search-alias=popular");

		//selectobj.selectByContainsVisibleText("");
		
		
		
		//De-select An Option
		
		selectobj.deselectAll();
		
//		selectobj.deselectByIndex(0);
//		selectobj.deselectByVisibleText("");
//		selectobj.deselectByValue("");
//		selectobj.deSelectByContainsVisibleText("");
//		
//		
//		
//		//To Fetch the Option
//		List<WebElement> option = selectobj.getOptions();
//		
//		WebElement firstselect = selectobj.getFirstSelectedOption();
//		
//		List<WebElement> alloption = selectobj.getAllSelectedOptions();
//		
//		
		
		
		
		
		
		
		
		
		
		
		

		driver.quit();
		System.out.println("Execution Completed..!!!");
	}
}
