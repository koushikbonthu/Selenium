package LearningWebDriverMethods;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearningBrowserNavigations {

	public static void main(String[] args) throws MalformedURLException, InterruptedException {

		// Step1:Launch the Browser
		WebDriver driver = new ChromeDriver();

		// Nav to App
		driver.navigate().to(new URL("https://www.naukri.com/"));

		driver.navigate().to("https://in.linkedin.com/");

		driver.get("https://www.foundit.in/");

		driver.navigate().back();

		Thread.sleep(5000);
		driver.navigate().refresh();
		
		Thread.sleep(5000);
		driver.navigate().forward();

	}

}
