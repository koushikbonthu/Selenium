package LearningWebDriverMethods;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearningManage {
	public static void main(String[] args) throws InterruptedException {

		// Step1:Launch the Browser
		WebDriver driver = new ChromeDriver();

		Thread.sleep(5000);
		// Maximize the Browser
		driver.manage().window().maximize();

		Thread.sleep(5000);
		// Minimize the Browser
		driver.manage().window().minimize();

		// Step2:Navigate To The Application Via URL
		driver.get("https://www.qspiders.com/");

		// FullScreen mode
		driver.manage().window().fullscreen();

		// Fetch the Browser Size
		Dimension size = driver.manage().window().getSize();
		System.out.println("Browser Size-(Width,Height):" + size);

		// Fetch the Browser Position
		Point position = driver.manage().window().getPosition();
		System.out.println("Browser Position-(x,y):" + position);

		
		//Set the Browser Size
		driver.manage().window().setSize(new Dimension(500, 500));
		Thread.sleep(5000);
		
		
		
		
		//Set the Browser Position
		driver.manage().window().setPosition(new Point(200, 200));
		Thread.sleep(5000);
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		driver.quit();

	}
}
