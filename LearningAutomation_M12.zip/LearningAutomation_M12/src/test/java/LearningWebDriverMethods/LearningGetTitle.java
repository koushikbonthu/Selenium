package LearningWebDriverMethods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearningGetTitle {
	public static void main(String[] args) {

		// Step1:Launch the Browser
		WebDriver driver = new ChromeDriver();

		// Step2:Navigate To The Application Via URL
		driver.get("https://www.saucedemo.com/");

		String exp_title = "Swag Labs";

		// Fetch the Actual Title
		String actual_title = driver.getTitle();

		// Verify The Page-By Using Title
		if (exp_title.equals(actual_title)) {
			System.out.println("Title Verified: Test Pass");

		} else {
			System.out.println("Title Verified: Test Fail");

		}

		// Step10:Close the Browser
		driver.close();

	}
}
