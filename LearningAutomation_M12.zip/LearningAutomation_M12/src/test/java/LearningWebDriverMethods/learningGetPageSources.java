package LearningWebDriverMethods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class learningGetPageSources {

	public static void main(String[] args) {

		// Step1:Launch the Browser
		WebDriver driver = new ChromeDriver();

		// Step2:Navigate To The Application Via URL
		driver.get("https://www.amazon.com/");

		// Fetch The Source Code (HTML Code)
		System.out.println(driver.getPageSource());

		driver.quit();

	}
}
