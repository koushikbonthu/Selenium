package LearningWebDriverMethods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearningGetCurrentUrl {

	public static void main(String[] args) {
		// Step1:Launch the Browser
		WebDriver driver = new ChromeDriver();

		// Step2:Navigate To The Application Via URL
		driver.get("https://www.instagram.com/");

		String exp_url = "https://www.instagram.com/";

		// Fetch the Actual URL
		String actual_url = driver.getCurrentUrl();

		// Verify The Page-By Using Title
		if (exp_url.equals(actual_url)) {

			System.out.println("URL Verified: Test Pass");

		} else {

			System.out.println("URL Verified: Test Fail");

		}

		// Step10:Close the Browser
		driver.quit();
	}

}
