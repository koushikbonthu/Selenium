package BasicsAutomation;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LaunchBrowser {

	public static void main(String[] args) throws InterruptedException {

		 WebDriver driver = new ChromeDriver();

	        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

	        driver.manage().window().maximize();

	        driver.get("https://www.goibibo.com/");

	        Thread.sleep(3000);



	        //closing the popup,Because the login details wanted otp 

	        WebElement popupClose = driver.findElement(By.xpath("//span[@class='logSprite icClose']"));

	        popupClose.click();

	     

	        // Select "One Way" as provided in the requirements

	        WebElement oneWay = driver.findElement(By.xpath("//span[@class=\"sc-12foipm-70 fPPRk\"]"));

	        oneWay.click();

	        Thread.sleep(1000);

	     

	        // From Delhi sector of search bar

	        WebElement fromInput = driver.findElement(By.xpath("//p[text()='Enter city or airport']"));

	        fromInput.click();

	        WebElement fromText = driver.findElement(By.xpath("//input[@type='text']"));

	        fromText.sendKeys("Delhi");

	        Thread.sleep(1000);

	        WebElement selectDelhi = driver.findElement(By.xpath("//ul//li//span[contains(text(),'Delhi')]"));

	        selectDelhi.click();



	        // To Hyderabad sector of search bar

	        WebElement toInput = driver.findElement(By.xpath("//input[@type=\"text\"]"));

	        toInput.sendKeys("Hyderabad");

	        Thread.sleep(1000);

	        WebElement selectHyd = driver.findElement(By.xpath("//ul//li//span[contains(text(),'Hyderabad')]"));

	        selectHyd.click();
	        
	        // depature
	        
	        
	       WebElement date=driver.findElement(By.xpath("(//span[text()='Departure'])[1]"));
	       date.click();
	       
	       WebElement datea=driver.findElement(By.xpath("//div[@aria-label=\"Sat Jun 21 2025\"]"));
	       datea.click();
	      
	       WebElement date1=driver.findElement(By.xpath("//span[text()='Return']"));
	       date1.click();
	       WebElement date28=driver.findElement(By.xpath("(//p[text()='28'])[1]"));
	       date28.click();
	       
	  // Add 2 Adults and 1 Child

	        WebElement travellers = driver.findElement(By.xpath("//span[text()='Travellers & Class']"));

	        travellers.click();

	        WebElement addAdult = driver.findElement(By.xpath("(//button[@aria-label='Increase adults'])[1]")); // already 1 adult

	        addAdult.click(); // now 2 adults

	        WebElement addChild = driver.findElement(By.xpath("(//button[@aria-label='Increase children'])[1]"));

	        addChild.click(); // 1 child

	        WebElement doneBtn = driver.findElement(By.xpath("//button[text()='Done']"));

	        doneBtn.click();



	        // Click Search Flights

	        WebElement searchBtn = driver.findElement(By.xpath("//span[text()='SEARCH FLIGHTS']"));

	        searchBtn.click();



	        // Wait for results

	        Thread.sleep(8000); 



	        // Applying  Time Filter: 6 AM - 12 PM

	        WebElement morningFilter = driver.findElement(By.xpath("//span[text()='6AM - 12Noon']"));

	        morningFilter.click();

	        Thread.sleep(2000);



	        // Apply Airline Filters: IndiGo and Air India

	        WebElement indigoFilter = driver.findElement(By.xpath("//span[contains(text(),'IndiGo')]"));

	        indigoFilter.click();

	        Thread.sleep(1000);

	        WebElement airIndiaFilter = driver.findElement(By.xpath("//span[contains(text(),'Air India')]"));

	        airIndiaFilter.click();
	        // DONE - results should now show filtered flights

	        System.out.println("Filtered flight search completed.");

	}
		
	}
	


