package LearningIframe;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingCompoundFrame {

	public static void main(String[] args) {

		WebDriver driver = new ChromeDriver();
		
		
		
		driver.get("lkiujyhtgrfdsdfgopkl[puytredssdfghj");

		// 1.Clear the Name in the Name TextFied

		// 2.Enter "Yourname" in the Name TextField

		driver.switchTo().frame(0);
		// 3.Enter "Computer" in the 1st Frame "SearchBox"

		driver.switchTo().defaultContent();
		// 4.Enter the Email in the Email TextFied

		driver.switchTo().frame(1);
		// 5.Enter "Books" in the 2nd Frame "SearchBox"

		driver.switchTo().defaultContent();
		// 6.Enter the "Password" in the Password TextFied

	}

}
