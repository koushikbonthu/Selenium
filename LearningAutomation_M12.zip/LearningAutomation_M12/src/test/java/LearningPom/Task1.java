package LearningPom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import PageRepository.LoginPage;

/**
 * To Show The Stale Element Reffrence Exception
 */
public class Task1 {

	@Test(enabled = false)
	public void performLogin() {
		WebDriver driver = new ChromeDriver();

		driver.get("https://www.saucedemo.com/");

		WebElement username_textfield = driver.findElement(By.id("user-name"));
		WebElement password_textfield = driver.findElement(By.id("password"));
		WebElement loginbutton = driver.findElement(By.id("login-button"));

		driver.navigate().refresh();

		loginbutton.click();

	}

	@Test(enabled = true)
	public void performLogin_with_POM() throws InterruptedException {

		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/");

		LoginPage loginobj = new LoginPage(driver);
		
		
		
		driver.navigate().refresh();
		Thread.sleep(5000);
		
		
		
		driver.navigate().refresh();
		Thread.sleep(5000);
		
		
		
		
		driver.navigate().refresh();
		Thread.sleep(5000);
		
		
		
		driver.navigate().refresh();
		Thread.sleep(5000);
		
		
		//Click On Login Button
		loginobj.getloginbutton().click();
		

	}

}
