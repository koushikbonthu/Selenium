package LearningJavaScriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class HandlingScrollling {
	public static void main(String[] args) throws InterruptedException{
	WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.selenium.dev/");
		// Using ScrollBy
		// 1.
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)");
		Thread.sleep(3000);
		js.executeScript("window.scrollBy(0,1000)");
		Thread.sleep(3000);
		js.executeScript("window.scrollBy(0,500)");
		Thread.sleep(3000);
		// 2.Using ScrollTo
		js.executeScript("window.scrollTo(0,500)");
		Thread.sleep(3000);
		js.executeScript("window.scrollTo(0,1000)");
		Thread.sleep(3000);

		js.executeScript("window.scrollTo(0,500)");
		Thread.sleep(3000);

		// 3.Using ScrollIntoView

		WebElement element = driver.findElement(By.xpath("//h2[text()='Nuews']"));

		js.executeScript("arguments[0].scrollIntoView(true)", element);
		Thread.sleep(5000);

		// 3.
		js.executeScript("arguments[0].scrollIntoView(false)", element);

		Thread.sleep(5000);

		driver.close();

		System.out.println("Execution Done!!!!");
	}

}
