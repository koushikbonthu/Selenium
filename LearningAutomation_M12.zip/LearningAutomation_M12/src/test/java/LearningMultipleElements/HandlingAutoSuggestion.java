package LearningMultipleElements;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingAutoSuggestion {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = new ChromeDriver();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

		driver.get("https://www.google.co.in/");

		// Identify the Search Box
		WebElement searchbox = driver.findElement(By.cssSelector("textarea[name='q']"));

		// Enter the Data/input --selenium
		searchbox.sendKeys("selenium");

		// Fetch All the Suggestion---Using FE's
		List<WebElement> allsuggetion = driver.findElements(By.xpath("//span[contains(text(),'selenium')]"));

		// Fetch the Suggestions Count And Print
		int count = allsuggetion.size();
		System.out.println("Count Of the Suggestion is :" + count);

		// Fetch all the Suggestion Text and Print
		for (int i = 0; i < count; i++) {

			String text = allsuggetion.get(i).getText();
			System.out.println(text);

		}

		Thread.sleep(5000);
		// close the Browser
		driver.quit();

	}

}
