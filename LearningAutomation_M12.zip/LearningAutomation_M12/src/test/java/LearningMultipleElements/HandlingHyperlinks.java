package LearningMultipleElements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * Verify User Able to Fetch all the Hyperlinks Text
 */
public class HandlingHyperlinks {

	public static void main(String[] args) {

		// Step1:launch the Browser
		WebDriver driver = new ChromeDriver();

		// Step2:Navigate to application via URL
		driver.get("https://www.ajio.in/");

		// Step3:Verify the Home Page is Displayed
		String exp_title = "";
		String actual_title = driver.getTitle();

		if (exp_title.equals(actual_title)) {
			System.out.println("Title Verified: Test Pass");
		} else {
			System.out.println("Title Verified: Test Fail");

		}

		// Step4:Fetch all the HyperLinks
		List<WebElement> alllinks = driver.findElements(By.xpath("//a"));

		// Step5:Fetch the Count and Print
		int count = alllinks.size();
		System.out.println("Count is :"+count);

		// Step5.1:Print all the Hyperlinks Text
		for (int i = 0; i < count; i++) {
			String text = alllinks.get(i).getText();
			System.out.println(text);

	
}		

		// Step6:Close the Browser
		driver.close();

	}

}
