package LearningMultipleElements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingWebTable {

	public static void main(String[] args) {

		// Open Browser
		WebDriver driver = new ChromeDriver();

		// Nav To Url
		driver.get("https://www.tutorialspoint.com/selenium/practice/webtables.php");

		
		List<WebElement> allemp;

		// 1.Fetch First Name of All Emp and Print

		allemp = driver.findElements(By.xpath("//tbody/tr/td[1]"));

		for (WebElement webElement : allemp)
			System.out.println(webElement.getText());
		System.out.println("---------------");
		

		// 2.Fetch 1st Emp Details and Print
		allemp = driver.findElements(By.xpath("//tbody/tr[1]/td"));
		for (WebElement webElement : allemp)
			System.out.println(webElement.getText());
		
		System.out.println("---------------");


		// 3.Fetch Email of All emp and Print
		allemp = driver.findElements(By.xpath("//tbody/tr/td[4]"));
		for (WebElement webElement : allemp)
			System.out.println(webElement.getText());
		System.out.println("---------------");


		// 4.Fetch 3rd Emp Details and Print
		allemp = driver.findElements(By.xpath("//tbody/tr[3]/td"));
		for (WebElement webElement : allemp)
			System.out.println(webElement.getText());
		
		System.out.println("---------------");


		// 5.Fetch Department of 4th emp and Print
		WebElement dept = driver.findElement(By.xpath("//tbody/tr[4]/td[6]"));
		System.out.println(dept.getText());
		System.out.println("---------------");



		// 6.Fetch salary of 4th emp and Print
		WebElement salary = driver.findElement(By.xpath("//tbody/tr[4]/td[5]"));
		System.out.println(salary.getText());

	}

}
