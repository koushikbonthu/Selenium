package LearningPopups;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class HandlingNotificationPopup {

	public static void main(String[] args) {

		// Customize the Browser Settings

		// 1.Create an Instance for ChromeOptions Class
		ChromeOptions option = new ChromeOptions();

		// 2.Call the non static method addArguments

		// 3.Pass the Chromium Commands to Disable Notification
		option.addArguments("--disable-notifications");

		// 4.Provide the Customized Setting to the Test-Browser
		WebDriver driver = new ChromeDriver(option);

		driver.get("https://www.easemytrip.com/");

	}

}
