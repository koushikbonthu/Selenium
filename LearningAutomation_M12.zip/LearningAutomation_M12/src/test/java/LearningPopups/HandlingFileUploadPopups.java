package LearningPopups;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingFileUploadPopups {

	public static void main(String[] args) {

		WebDriver driver = new ChromeDriver();

		driver.get("https://the-internet.herokuapp.com/upload");

		WebElement choosefile = driver.findElement(By.id("file-upload"));

		// How to Handle the File Upload Popups:

		// 1.Create an instance For File Class
		File file = new File("./src/test/resources/MySeleniumNotes.txt");

		// 2.Fetch teh Absolute Path
		String absolutepath = file.getAbsolutePath();

		// 3.Pass the File to be Upload
		choosefile.sendKeys(absolutepath);
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
