package LearningPopups;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingChildWIndowPopups {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = new ChromeDriver();

		driver.get("https://www.tutorialspoint.com/selenium/practice/browser-windows.php");

		driver.findElement(By.xpath("//button[text()='New Window']")).click();

		// Fetch the Parent Session id
		String parentid = driver.getWindowHandle();
		System.out.println(parentid);

		// Fetch all the Session Id
		Set<String> allid = driver.getWindowHandles();

		System.out.println("--------------------------------");

		// 1. Close all the window Without Using Quit
//		for (String all : allid) {
//
//			driver.switchTo().window(all);
//
//			System.out.println(all);
//			driver.close();
//
//		}

		// 2.Close the Child popup only

		for (String all : allid) {

			driver.switchTo().window(all);

			if (all.equals(parentid)) {

			}

			else {
				driver.close();
			}

		}

		System.out.println("--------------------------------");

	}

}
