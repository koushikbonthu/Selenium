package LearningPopups;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingAlertpopups {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();

		driver.get("https://www.tutorialspoint.com/selenium/practice/alerts.php");

		driver.findElement(By.xpath("//button[text()='Alert']")).click();

		// ---------Handle ALert Popups---------

		String text = driver.switchTo().alert().getText();
		System.out.println(text);

		// driver.switchTo().alert().sendKeys("Learning Alert popups");

		Thread.sleep(5000);
		// driver.switchTo().alert().accept();

		driver.switchTo().alert().dismiss();
		driver.quit();

	}
}
