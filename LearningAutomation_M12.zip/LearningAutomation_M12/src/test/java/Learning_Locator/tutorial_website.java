package Learning_Locator;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class tutorial_website {
	public static void main(String [] args)
	{
		WebDriver driver=new ChromeDriver();
		driver.navigate().to("https://www.tutorialspoint.com/selenium/practice/text-box.php");
		driver.findElement(By.name("fullname")).sendKeys("Ashritha");
		driver.findElement(By.id("email")).sendKeys("sanas234@gmail,com");
		driver.findElement(By.id("address")).sendKeys("ydgcjhdcja354874hgdjsb");
		driver.findElement(By.id("password")).sendKeys("cahiks132@67");
		driver.quit();

		
	}

}
