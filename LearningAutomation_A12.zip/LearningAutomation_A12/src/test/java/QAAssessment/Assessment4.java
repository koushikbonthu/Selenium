package QAAssessment;


import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Assessment4 {

	public static void main(String[] args) throws MalformedURLException, InterruptedException {

		// Launch the browser
		WebDriver driver = new ChromeDriver();

		// Maximize the browser
		driver.manage().window().maximize();

		// Navigate to Demo web shop
		driver.navigate().to(new URL("https://magento.softwaretestingboard.com/"));

		// Verify the page URL
		String expectedURL = "https://magento.softwaretestingboard.com/";
		String actualURL = driver.getCurrentUrl();
		System.out.println(actualURL);
		if (expectedURL.equalsIgnoreCase(actualURL)) {
			System.out.println("Page Verification successfull");
		}

		// Locate SignIn Link
		WebElement signin = driver.findElement(By.xpath("(//a[contains(text(),'Sign In')] )[1]"));

		// Click on SignIn Link
		signin.click();

		// Verify the text //span[contains(text(),'Customer Login')]
		WebElement expectedelement = driver.findElement(By.xpath("//span[contains(text(),'Customer Login')]"));
		if (expectedelement.isDisplayed()) {
			System.out.println("Login Page Verification successfull");
		}

		// Locate email TextField
		WebElement email = driver.findElement(By.id("email"));

		// Enter email
		email.sendKeys("chandlerbing@friends.com");

		// Locate password TextField
		WebElement password = driver.findElement(By.id("pass"));

		// Enter Password
		password.sendKeys("Chandlerbing@3");

		// Locate Login Button
		WebElement login = driver.findElement(By.xpath("//button[@id='send2' and @class='action login primary']"));

		// Click on Login Button
		login.click();

		// Verify the text
		WebElement expectedelement2 = driver.findElement(By.xpath("//span[text()='Home Page']"));
		if (expectedelement2.isDisplayed()) {
			System.out.println("Home Page Verification successfull");
		}

		// Locate Profile DropDown
		WebElement drpdwn = driver
				.findElement(By.xpath("//div[@class='panel header']/ul[@class='header links']/li[2]"));

		// Click on DropDown
		drpdwn.click();

		// Wait statement
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));

		// Expected condition
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[contains(text(),'My Account')])[1]")));

		// Locate My Profile Button
		WebElement myProfile = driver.findElement(By.xpath("(//a[contains(text(),'My Account')])[1]"));

		// Click on My Profile Button
		myProfile.click();

		Thread.sleep(5);
		// Locate Change Password element
		WebElement changePassword = driver.findElement(By.xpath("//a[contains(text(),'Change Password')]"));

		// Click on Change Pasasword element
		changePassword.click();

		Thread.sleep(2);

		// Locate current password text field
		WebElement current = driver.findElement(By.cssSelector("#current-password"));

		// Enter Current Password
		current.sendKeys("Chandlerbing@3");

		// Locate New password text field
		WebElement newpass = driver.findElement(By.id("password"));

		// Enter New Password
		newpass.sendKeys("Chandler@3");

		// Locate Confirm password text field
		WebElement conpass = driver.findElement(By.id("password-confirmation"));

		// Enter Confirm Password
		conpass.sendKeys("Chandler@3");

		// Locate Save button
		WebElement save = driver.findElement(By.xpath("//span[text()='Save']"));

		// Click on save button
		save.click();

	}

}
