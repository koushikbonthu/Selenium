package QAAssessment;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class Assessment2 {

	public static void main(String[] args) throws MalformedURLException {

		// Launch the browser
		WebDriver driver = new EdgeDriver();

		// Maximize the browser
		driver.manage().window().maximize();

		// Navigate to Demo web shop
		driver.navigate().to(new URL("https://magento.softwaretestingboard.com/"));

		// Verify the page URL
		String expectedURL = "https://magento.softwaretestingboard.com/";
		String actualURL = driver.getCurrentUrl();
		System.out.println(actualURL);
		if (expectedURL.equalsIgnoreCase(actualURL)) {
			System.out.println("Page Verification successfull");
		}

		// Locate SignIn Link
		WebElement signin = driver.findElement(By.xpath("(//a[contains(text(),'Sign In')] )[1]"));

		// Click on SignIn Link
		signin.click();

		// Verify the text
		WebElement expectedelement = driver.findElement(By.xpath("//span[contains(text(),'Customer Login')]"));
		if (expectedelement.isDisplayed()) {
			System.out.println("Login Page Verification successfull");
		}

		// Locate email TextField
		WebElement email = driver.findElement(By.id("email"));

		// Enter email
		email.sendKeys("chandlerbing@friends.com");

		// Locate password TextField
		WebElement password = driver.findElement(By.id("pass"));

		// Enter Password
		password.sendKeys("Chandlerbing@3");

		// Locate Login Button
		WebElement login = driver.findElement(By.xpath("//button[@id='send2' and @class='action login primary']"));

		// Click on Login Button
		login.click();

		// Verify the text
		WebElement expectedelement2 = driver.findElement(By.xpath("//span[text()='Home Page']"));
		if (expectedelement2.isDisplayed()) {
			System.out.println("Home Page Verification successfull");
		}
		
		//Close the browser
		driver.quit();

	}

}
