package QAAssessment;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class Assessment1 {

	public static void main(String[] args) throws MalformedURLException {

		// Launch the browser
		WebDriver driver = new EdgeDriver();

		// Maximize the browser
		driver.manage().window().maximize();

		// Navigate to Demo web shop
		driver.navigate().to(new URL("https://magento.softwaretestingboard.com/"));

		// Verify the page URL
		String expectedURL = "https://magento.softwaretestingboard.com/";
		String actualURL = driver.getCurrentUrl();
		System.out.println(actualURL);
		if (expectedURL.equalsIgnoreCase(actualURL)) {
			System.out.println("Page Verification successfull");
		}

		// Locate SignUp
		WebElement signup = driver.findElement(By.linkText("Create an Account"));

		// Click on SignUp Link
		signup.click();

		// Verify the page URL
		String expectedURL2 = "https://magento.softwaretestingboard.com/customer/account/create/";
		String actualURL2 = driver.getCurrentUrl();
		System.out.println(actualURL2);
		if (expectedURL2.equalsIgnoreCase(actualURL2)) {
			System.out.println("Page Verification successfull");
		}

		// Locate First Name TextField
		WebElement firstName = driver.findElement(By.id("firstname"));

		// Enter in First Name TextField
		firstName.sendKeys("Chandler");

		// Locate last Name TextField
		WebElement lastName = driver.findElement(By.id("lastname"));

		// Enter in Last Name TextField
		lastName.sendKeys("Bing");

		// Locate Email TextField
		WebElement email = driver.findElement(By.id("email_address"));

		// Enter email in Email TextField
		email.sendKeys("chandlerbing@friends.com");

		// Locate password TextField
		WebElement password = driver.findElement(By.id("password"));

		// Enter password in password TextField
		password.sendKeys("Chandlerbing@3");

		// Locate Confirm Password TextField
		WebElement cpassword = driver.findElement(By.id("password-confirmation"));

		// Enter Password in Confirm Password TextField
		cpassword.sendKeys("Chandlerbing@3");

		// Locate Create account button
		WebElement createAccount = driver.findElement(By.xpath("//button[@title='Create an Account']"));

		// Click On Create Button
		createAccount.click();

		// Close the browser
		driver.quit();

	}

}
