package WebElementPerformActions;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearningPerformActions {

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		//Launch Browser
		WebDriver driver = new ChromeDriver();
				
		//Navigate to URL
		driver.navigate().to(new URL("https://www.saucedemo.com/"));
				
		//Locate username Textfield
		WebElement usernametextfield = driver.findElement(By.xpath("(//input)[1]"));
		
		//Locate Password Textfield
		WebElement passwordtextfield = driver.findElement(By.xpath("(//input)[2]"));
		
		//Locate Login Button
		WebElement Loginbutton = driver.findElement(By.xpath("(//input)[3]"));
		
		Thread.sleep(3000);
		//Enter invalid Username in Username textfield
		usernametextfield.sendKeys("qwertyuiop");
		
		Thread.sleep(3000);
		//Clear invalid Username in Username Textfield
		usernametextfield.clear();
		
		Thread.sleep(3000);
		//Enter Valid Username in Username textfield
		usernametextfield.sendKeys("locked_out_user");
		
		Thread.sleep(3000);
		//Clear invalid Username in Username Textfield
		usernametextfield.clear();
		
		Thread.sleep(3000);
		//Enter Valid Username in Username textfield
		usernametextfield.sendKeys("problem_user");
		
		Thread.sleep(3000);
		//Clear invalid Username in Username Textfield
		usernametextfield.clear();
		
		Thread.sleep(3000);
		//Enter Valid Username in Username textfield
		usernametextfield.sendKeys("performance_glitch_user");
		
		Thread.sleep(3000);
		//Clear invalid Username in Username Textfield
		usernametextfield.clear();
		
		Thread.sleep(3000);
		//Enter Valid Username in Username textfield
		usernametextfield.sendKeys("error_user");
		
		Thread.sleep(3000);
		//Clear invalid Username in Username Textfield
		usernametextfield.clear();
		
		Thread.sleep(3000);
		//Enter Valid Username in Username textfield
		usernametextfield.sendKeys("visual_user");
		
		Thread.sleep(3000);
		//Clear invalid Username in Username Textfield
		usernametextfield.clear();
		
		Thread.sleep(3000);
		//Enter Valid Username in Username textfield
		usernametextfield.sendKeys("standard_user");
		
		Thread.sleep(3000);
		//Enter invalid Password in Password textfield
		passwordtextfield.sendKeys("qwertyuiop");
		
		Thread.sleep(3000);
		//Clear invalid Password in Password Textfield
		passwordtextfield.clear();
		
		Thread.sleep(3000);
		//Enter Valid Password in Password textfield
		passwordtextfield.sendKeys("secret_sauce");
		
		Thread.sleep(3000);
		//Submit the form
		Loginbutton.submit();
		
		Thread.sleep(3000);
		
		//Close the browser
		driver.quit();
		
	}

}
