package LearningAssertion;

import org.testng.Assert;
import org.testng.annotations.Test;

public class hardAssert {

	@Test
	
	public void m1() {
		
		String expectedconditon = "Swag Labs";
		String actualcondition = "Swag Labs";
		
		boolean expectedcondition1 = true;
		boolean actualconditon1 = true;
		
		int expectedcondition2 = 10;
		int actualconditon2 = 10;
		
		//Assert.assertEquals(actualcondition,expectedconditon);
		Assert.assertEquals(actualconditon2 ,expectedcondition2);
		
		System.out.println("Line 4");
	}

}
