package Locators;

import java.net.MalformedURLException;
import java.net.URL;import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class learnId {

	public static void main(String[] args) throws MalformedURLException {
		//Launch the browser
		WebDriver driver = new ChromeDriver();
		//Step2: Maximize the browser
		driver.manage().window().maximize();
		//Navigate to application
		driver.navigate().to(new URL("https://www.saucedemo.com/v1/"));
		//Locate username texfield
		WebElement usernameTextfield = driver.findElement(By.id("user-name"));
		//Enter username
		usernameTextfield.sendKeys("standard_user");
		//Locate password texfield
		WebElement passwordTextfield = driver.findElement(By.id("password"));
		//Enter password
		passwordTextfield.sendKeys("secret_sauce");
		//Locate login button
		WebElement loginButton = driver.findElement(By.id("login-button"));
		//click on login
		loginButton.click();
		//close the browser
		driver.quit();
		
		
	}

}
