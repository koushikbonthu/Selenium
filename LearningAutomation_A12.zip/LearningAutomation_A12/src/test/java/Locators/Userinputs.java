package Locators;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Userinputs {

    public static void main(String[] args) throws MalformedURLException {
        Scanner sc = new Scanner(System.in);
        WebDriver driver = null;

        System.out.println("Enter browser name:");
        String browser = sc.next();
        String browserName = "";

        // Convert to Upper-case
        for (int i = 0; i < browser.length(); i++) {
            char c = browser.charAt(i);
            if (c >= 'a' && c <= 'z') {
                c = (char) (c - 32);
            }
            browserName = browserName + c;
        }
        System.out.println("Enter username");
        String username= sc.next();
       /* String originalUn="chandlerbing@friends.com";
        WebElement warningUN= driver.findElement(By.linkText("Please enter a valid email address."));
        if(username.equalsIgnoreCase(originalUn))
        {
        	System.out.println();
        }*/
        System.out.println("Enter password");
        String password= sc.next();
        // Launch browser
        switch (browserName) {
            case "CHROME":
                driver = new ChromeDriver();
                break;
            case "EDGE":
                driver = new EdgeDriver();
                break;
            case "FIREFOX":
                driver = new FirefoxDriver();
                break;
            default:
                System.out.println("Enter correct Browser");
                break;
        }

        // Maximize the browser
        driver.manage().window().maximize();

        // Navigate to the application
        driver.navigate().to(new URL("https://demowebshop.tricentis.com/"));

        // Verify URL
        String expectedUrl = "https://demowebshop.tricentis.com/";
        String actualUrl = driver.getCurrentUrl();
        System.out.println(actualUrl);
        if (expectedUrl.equalsIgnoreCase(actualUrl)) {
        	
            System.out.println("URL verification successful");
            System.out.println("___________________X_____________________");
        }
        //Locate Login link
		WebElement loginlink = driver.findElement(By.linkText("Log in"));
		//Click on " Login "  link
		loginlink.click();
		//Verify if Login page is displayed
		String expectedURL1="https://demowebshop.tricentis.com/login";
		String actualURL1= driver.getCurrentUrl();
		System.out.println(actualURL1);
		if(expectedURL1.equalsIgnoreCase(actualURL1))
		{
			
			System.out.println("Login Page Verification successfull");
			System.out.println("___________________X_____________________");
		}
		
		//Locate Email Text-field
		WebElement emailtextfield = driver.findElement(By.name("Email"));
		//Enter email in "Email " Text-field
		emailtextfield.sendKeys(username);//chandlerbing@friends.com
		//Locate password Text-field
		WebElement passwordtextfield = driver.findElement(By.name("Password"));
		//Enter Password in "Password" Text-field
		passwordtextfield.sendKeys(password);//chandlerbing
		//passwordtextfield.sendKeys(password,Keys.ENTER);//chandlerbing
		//Locate Login button
		WebElement loginbutton = driver.findElement(By.className("login-button"));
		//WebElement loginbutton = driver.findElement(By.xpath("//input[@class='button-1 login-button']"));
		
		//Click on "Log In" button
		loginbutton.click();
		//Verify if Home page is displayed
		String expectedURL2="https://demowebshop.tricentis.com/";
		String actualURL2= driver.getCurrentUrl();
		System.out.println(actualURL2);
		if(expectedURL2.equalsIgnoreCase(actualURL2))
		{
			
			System.out.println("Home Page Verification successfull");
			System.out.println("___________________X_____________________");
		}

        // Close browser
        driver.quit();
        sc.close();
    }
}
