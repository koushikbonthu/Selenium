package LearningPOM;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import PageRepository.HomePage;
import PageRepository.LoginPage;
import PageRepository.Logout;

public class First_Scenario {
	WebDriver driver;

	@BeforeClass
	public void browserSetup() {

		driver = new EdgeDriver();
		Reporter.log("Browser opened successfully", true);

		driver.manage().window().maximize();

		driver.get("https://www.saucedemo.com/");
		Reporter.log("Nav to Application successfull", true);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2000));
	}

	@BeforeMethod
	public void login() {
		// Create Object for LoginPage(POMClass)
		LoginPage lobj = new LoginPage(driver);

		// Use the web elements from LoginPage POM Class
		lobj.getusernameTextfield().sendKeys("standard_user");
		lobj.getpasswordTextfield().sendKeys("secret_sauce");
		lobj.getLoginButton().click();
		Reporter.log("Login successfull", true);
	}

	@Test(enabled = true)
	public void addProduct() {
		// Create object for HomePage POM Class
		HomePage h2obj = new HomePage(driver);

		// Add product to cart from homepage
		h2obj.getproduct1().click();
		h2obj.getaddTocart().click();
		h2obj.getcartIcon().click();
		Reporter.log("Product added successfully", true);

	}

	@Test(enabled = true)
	public void addMultipleProduct() {
		// Create object for HomePage POM Class
		HomePage hobj = new HomePage(driver);

		// Add product to cart from homepage
		for (int i = 0; i < hobj.getproducts().size(); i++) {
			hobj.getproducts().get(i).click();
			hobj.getaddTocart().click();
			hobj.getBack().click();

		}
		hobj.getcartIcon().click();
		Reporter.log("Products added successfully", true);

	}

	@AfterMethod(enabled = true)
	public void logout() {
		// Create Object for Logout POM class
		Logout logout = new Logout(driver);

		// Use web elements from Logout(POMClass)
		logout.getmenu().click();
		logout.getlogoutBtn().click();
		Reporter.log("Log out successfull", true);
	}

	@AfterClass(enabled = true)
	public void browserTermination() {
		driver.close();
		Reporter.log("Browser closed successfully", true);
	}

}
