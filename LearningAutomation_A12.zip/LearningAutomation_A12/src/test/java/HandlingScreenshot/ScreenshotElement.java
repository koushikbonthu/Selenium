package HandlingScreenshot;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.io.FileHandler;

public class ScreenshotElement {

	public static void main(String[] args) throws IOException {
		
				WebDriver driver = new EdgeDriver();
				driver.manage().window().maximize();
				driver.navigate().to(new URL("https://www.selenium.dev/"));
				System.out.println("Page title: " + driver.getTitle());
				
				//Locate the element
				WebElement element = driver.findElement(By.xpath("//h2[text()='News']"));
				
				//Call the Screenshot method and store the screenshot in temp path
				File temp = element.getScreenshotAs(OutputType.FILE);
				
				//Create a permanent path for storing screenshot
				File permanent = new File("./Screenshots/SecondScreenshot.png");
				
				//Copy the screenshot from temp to permanent
				FileHandler.copy(temp, permanent);
				
				//Close the browser
				driver.quit();

				System.out.println("Screenshot Taken");

	}

}
