package HandlingMouseActions;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingHiddenElement {

	public static void main(String[] args) throws MalformedURLException {
		// Launch the browser
		WebDriver driver = new EdgeDriver();

		// Maximize the browser
		driver.manage().window().maximize();

		// Navigate to Demo web shop
		driver.navigate().to(new URL("https://demowebshop.tricentis.com/"));

		// Locate the Computers element
		WebElement computers = driver.findElement(By.xpath("//div[@class=\"header-menu\"]/ul/li[2]/a"));

		// Locate the Accessories element
		WebElement accessories = driver.findElement(By.xpath("//ul[@class='sublist firstLevel']/li[3]/a"));

		// Create an object for actions class
		Actions object = new Actions(driver);

		// Call the mandatory method and non static methods and move to computers
		object.moveToElement(computers).perform();

		// Call the mandatory method and non static methods and click on accessories
		// object.moveToElement(accessories).click().perform();
		object.moveToElement(accessories).doubleClick().perform();
		// object.moveToElement(accessories).contextClick().perform();

		// Close the browser
		driver.quit();
	}

}
