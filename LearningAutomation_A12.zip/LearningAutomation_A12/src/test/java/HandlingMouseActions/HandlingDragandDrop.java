package HandlingMouseActions;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

public class HandlingDragandDrop {

	public static void main(String[] args) throws MalformedURLException {
		// Launch the browser
		WebDriver driver = new EdgeDriver();

		// Maximize the browser
		driver.manage().window().maximize();

		// Navigate to Demo web shop
		driver.navigate().to(new URL("http://www.dhtmlgoodies.com/scripts/drag-drop-custom/demo-drag-drop-3.html"));

		// Create an object for actions class
		Actions object = new Actions(driver);
		
		//Drag and Drop Respective elements
		for (int i = 1; i <= 7; i++) 
		{
			for (int j = 101; j <= 107; j++)
			{
				if (i+100 == j) 
				{
					//object.dragAndDrop(driver.findElement(By.id("box"+i)), driver.findElement(By.id("box"+j))).perform();
					object.clickAndHold(driver.findElement(By.id("box"+i))).release(driver.findElement(By.id("box"+j))).perform();
				}
			}
		}
		// Close the browser
		driver.quit();

	}

}
