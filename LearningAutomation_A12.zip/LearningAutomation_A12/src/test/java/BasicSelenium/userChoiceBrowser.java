package BasicSelenium;

import java.util.Scanner;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class userChoiceBrowser {

	
	void invalid()
	{
		for(int i=1;i<=3;i++)
		{
			
		}
	}
	public static void main(String[] args) {
		int a= 1;
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter author name");
		String name= sc.next();
		
		System.out.println("Enter the browser in lowercase");
		String browser= sc.next();
		String browserName="";
		for (int i = 0; i < browser.length(); i++) {
			char c= browser.charAt(i);
			if(c>='a'&&c<='z')
			{
				c=(char)(c-32);
			}
			browserName=browserName+c;
		}
				
		if(browserName.equalsIgnoreCase("CHROME"))
		{
			//Step1: Open the browser-Chrome
			ChromeDriver driver =	new ChromeDriver();
			//Step2: Navigate to application via URL
			driver.get("https://www.youtube.com/");
			//Step3: Close the browser
			driver.close();
			System.out.println("Execution Completed by "+name+" in Chrome");
		}
		
		else if(browserName.equalsIgnoreCase("EDGE"))
		{
			//Step1: Open the browser-Chrome
			EdgeDriver driver =	new EdgeDriver();
			//Step2: Navigate to application via URL
			driver.get("https://www.youtube.com/");
			//Step3: Close the browser
			driver.close();
			System.out.println("Execution Completed by "+name+" in Edge");
		}
		else if(browserName .equalsIgnoreCase("FIREFOX"))
		{
			//Step1: Open the browser-Chrome
			FirefoxDriver driver =	new FirefoxDriver();
			//Step2: Navigate to application via URL
			driver.get("https://www.youtube.com/");
			//Step3: Close the browser
			driver.close();
			System.out.println("Execution Completed by "+name+" in Firefox");
		}
		else
		{
			System.out.println("Enter valid browser");
			userChoiceBrowser i = new userChoiceBrowser();
			i.invalid();
		}
		

	}

}
