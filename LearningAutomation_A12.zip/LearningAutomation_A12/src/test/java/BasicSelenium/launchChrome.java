package BasicSelenium;

import org.openqa.selenium.chrome.ChromeDriver;

public class launchChrome {

	public static void main(String[] args) {
		 
			//Step1: Open the browser-Chrome
			ChromeDriver driver =	new ChromeDriver();
			//Step2: Navigate to application via URL
			driver.get("https://www.youtube.com/");
	
		System.out.println("Execution Completed by ");
	}

}
