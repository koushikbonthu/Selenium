package BasicSelenium;

import org.openqa.selenium.edge.EdgeDriver;

public class launchEdge {

	public static void main(String[] args) {
				//Step1: Open the browser-Chrome
				EdgeDriver driver =	new EdgeDriver();
				//Step2: Navigate to application via URL
				driver.get("https://www.youtube.com/");
				//Step3: Login
				
				//Verify the page
				
				//Step4: Order the product
				
				//Step5: 
				//Step6: 
				//Step7: 
				//Step8: 
				//Step9: Logout
						
				//Step10: Close the browser
				driver.close();
				System.out.println("Execution Completed");

	}

}
