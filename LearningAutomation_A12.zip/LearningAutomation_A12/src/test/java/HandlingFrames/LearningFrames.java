package HandlingFrames;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class LearningFrames {

	public static void main(String[] args) throws MalformedURLException {
		// Launch the browser
		WebDriver driver = new EdgeDriver();

		// Maximize the browser
		driver.manage().window().maximize();

		// Navigate to Demo web shop
		driver.navigate().to(new URL("https://the-internet.herokuapp.com/nested_frames"));
		
		//Wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		
		//Switch to Frame using "Index"
		//driver.switchTo().frame(1);
		
		//Switch to Frame using "String"
		//driver.switchTo().frame("frame-bottom");
		
		//Switch to Frame using "WebElement"
		WebElement frame = driver.findElement(By.xpath("//frame[@name='frame-bottom']"));
		driver.switchTo().frame(frame);

		//Verification
		WebElement element= driver.findElement(By.xpath("//body[contains(text(),'BOT')]"));
		System.out.println(element.isDisplayed());
		
		//Close the browser
		driver.quit();
		
	}

}
