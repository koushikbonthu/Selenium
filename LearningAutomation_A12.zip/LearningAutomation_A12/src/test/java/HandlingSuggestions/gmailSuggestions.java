package HandlingSuggestions;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class gmailSuggestions {

	public static void main(String[] args) {

		// open the browser
		WebDriver driver = new EdgeDriver();

		// maximize
		driver.manage().window().maximize();

		// implicit wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// navigate to application via url
		driver.get("https://www.amazon.in/");

		// verify the page using title
		System.out.println("the title is :" + driver.getTitle());

		// identify all the suggestions and store it
		List<WebElement> allsuggestion = driver.findElements(By.xpath("//a"));

		// Count of Suggestions
		int count = allsuggestion.size();
		System.out.println(count);

		// for validate print the suggestion value
		for (int i = 0; i < count; i++) {
			String suggestion1 = allsuggestion.get(i).getText();
			System.out.println(suggestion1);
		}

		// close the browser
		driver.close();

	}

}
