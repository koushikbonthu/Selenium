package HandlingSuggestions;

import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class textfieldsuggestions {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Search product name");
		String data = sc.nextLine();
		// String dynamicdata="noise";

		// open the browser
		WebDriver driver = new ChromeDriver();

		// maximize
		driver.manage().window().maximize();

		// implicit wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		// navigate to application via url
		driver.get("https://www.amazon.in/");

		// verify the page using title
		System.out.println("the title is :" + driver.getTitle());

		// identify the search textfield and store it
		WebElement search = driver.findElement(By.cssSelector("input[placeholder='Search Amazon.in']"));

		// validate the element
		if ((search.isDisplayed()) && (search.isEnabled())) {
			System.out.println("searchbox is validated : Displayed & Enabled");
		} else {
			System.out.println("searchbox is validated : Not Displayed or Not Enabled");
		}

		// enter the dynamic data
		search.sendKeys(data);

		// identify all the suggestions and store it
		List<WebElement> allsuggestion = driver.findElements(By.xpath("//div[contains(text(),'" + data + "')]"));

		// Count of Suggestions
		int count = allsuggestion.size();
		System.out.println(count);

		// for validate print the suggestion value
		for (int i = 0; i < count; i++) {
			String suggestion1 = allsuggestion.get(i).getText();
			System.out.println(suggestion1);
		}

		// close the browser
		driver.close();

	}

}
