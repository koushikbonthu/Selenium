package demoWebShop;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import PageRepository.DWSLRegister;

public class RegisterMultipleUsers {

	WebDriver driver;

	@BeforeClass()
	public void BrowserSetup() {
		// Step1: Launch the browser
		driver = new EdgeDriver();
		// Step2: Maximize the browser
		driver.manage().window().maximize();
		// Step3: Navigate to application
		driver.get("https://demowebshop.tricentis.com/");
	}

	@BeforeMethod()
	public void Register1() throws InterruptedException {
		// Step4: Locate register link
		WebElement reglink = driver.findElement(By.linkText("Register"));
		// Step5: Click on " Register " link
		reglink.click();
		// Step6: Verify if "Register" page is displayed
		String expectedURL = "https://demowebshop.tricentis.com/register";
		String actualURL = driver.getCurrentUrl();
		System.out.println(actualURL);
		if (expectedURL.equalsIgnoreCase(actualURL)) {
			System.out.println("1st Verification successfull");
		}
		Thread.sleep(3000);
	}

	@DataProvider()
	public Object[][] users() {

		Object[][] user = new Object[3][6];

		user[0][0] = "Male";
		user[0][1] = "Ananthasish3";
		user[0][2] = "Asish3";
		user[0][3] = "asdfgh@gmail.com";
		user[0][4] = "1234567890";
		user[0][5] = "1234567890";

		user[1][0] = "Male";
		user[1][1] = "Asish3";
		user[1][2] = "Ananth3";
		user[1][3] = "wertyui@gmail.com";
		user[1][4] = "0987654321";
		user[1][5] = "0987654321";

		user[2][0] = "Female";
		user[2][1] = "Kajal3";
		user[2][2] = "Agarwal3";
		user[2][3] = "nihanth@kajal.com";
		user[2][4] = "qwertyuiop";
		user[2][5] = "qwertyuiop";

		return user;

	}

	@Test(dataProvider = "users")
	public void Register(String FirstName, String LastName, String email, String pwd, String cpwd) {

		// Create Object for RegisterPage(POM class)
		DWSLRegister obj = new DWSLRegister(driver);

		obj.getmale().click();
		obj.getFirstName().sendKeys(FirstName);
		obj.getLastName().sendKeys(LastName);
		obj.getEmail().sendKeys(email);
		obj.getPassword().sendKeys(pwd);
		obj.getConfirmPassword().sendKeys(cpwd);
		obj.getRegisterButton().click();

		/*
		 * // Step7: Locate Male radio button WebElement maleradio =
		 * driver.findElement(By.id("gender-male")); // Step 8: Locate Female radio
		 * button WebElement Femaleradio = driver.findElement(By.id("gender-female"));
		 * 
		 * if (gender.equals("Male")) { // Step 9: Select "Male" radio button
		 * maleradio.click(); } else { // Step 10: Select "Male" radio button
		 * Femaleradio.click(); } System.out.println("Gender selected");
		 * 
		 * // Step 11: Locate FirstName texfield WebElement firstnameTextfield =
		 * driver.findElement(By.id("FirstName")); // Step12: Enter firstname in
		 * "First Name " textfield firstnameTextfield.sendKeys(fname);
		 * System.out.println("first name entered");
		 * 
		 * // Step13: Locate LastName texfield WebElement lastnameTextfield =
		 * driver.findElement(By.id("LastName")); // Step14: Enter lastname in
		 * "Last Name " textfield lastnameTextfield.sendKeys(lname);
		 * System.out.println("Last name entered");
		 * 
		 * // Step15: Locate email textfield WebElement emailTextfield =
		 * driver.findElement(By.id("Email")); // Step16: Enter email in "Email "
		 * textfield emailTextfield.sendKeys(email);
		 * System.out.println("Email entered");
		 * 
		 * // Step17: Locate password texfield WebElement passwordTextfield =
		 * driver.findElement(By.id("Password")); // Step18: Enter password in password
		 * textfield passwordTextfield.sendKeys(pwd);
		 * System.out.println("Password entered");
		 * 
		 * // Step19: Locate confirmpassword texfield WebElement
		 * confirmpasswordTextfield = driver.findElement(By.id("ConfirmPassword")); //
		 * Step20: Enter Password in "Confirm Password" textfield
		 * confirmpasswordTextfield.sendKeys(cpwd);
		 * System.out.println("Confirm Password entered");
		 * 
		 * // Step21: Locate register button WebElement register =
		 * driver.findElement(By.id("register-button")); // Step22: Click on "Register"
		 * button register.click();
		 * System.out.println("**************Registration Completed******************");
		 * 
		 * 
		 */
	}

	@AfterClass()
	public void Browsertermination() {
		// Closer the browser
		driver.quit();
	}

}
