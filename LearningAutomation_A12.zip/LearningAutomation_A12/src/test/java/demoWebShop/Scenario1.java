package demoWebShop;


import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Scenario1 {

	public static void main(String[] args) throws MalformedURLException {
	//Step1: Launch the browser
		WebDriver driver = new ChromeDriver();
	//Step2: Maximize the browser
		driver.manage().window().maximize();
	//Step3: Navigate to application
		driver.navigate().to(new URL("https://demowebshop.tricentis.com/"));
	//Step4: Locate register link
		WebElement reglink = driver.findElement(By.linkText("Register"));
	//Step5: Click on " Register "  link
		reglink.click();
	//Step6: Verify if "Register" page is displayed
		String expectedURL="https://demowebshop.tricentis.com/register";
		String actualURL= driver.getCurrentUrl();
		System.out.println(actualURL);
		if(expectedURL.equalsIgnoreCase(actualURL))
		{
			System.out.println("1st Verification successfull");
		}		
	//Step7: Locate Male radio button
		WebElement maleradio = driver.findElement(By.id("gender-male"));
	//Step8: Select "Male" radio button
		maleradio.click();
	//Step9: Locate FirstName texfield
		WebElement firstnameTextfield = driver.findElement(By.id("FirstName"));
	//Step10: Enter firstname in "First Name " textfield
		firstnameTextfield.sendKeys("Chandler");
	//Step11: Locate LastName texfield
		WebElement lastnameTextfield = driver.findElement(By.id("LastName"));
	//Step12: Enter lastname in "Last Name " textfield
		lastnameTextfield.sendKeys("Bing");
	//Step13: Locate email textfield
		WebElement emailTextfield = driver.findElement(By.id("Email"));
	//Step14: Enter email in "Email " textfield
		emailTextfield.sendKeys("chandlerbing@friends.com");
	//Step15: Locate password texfield
		WebElement passwordTextfield = driver.findElement(By.id("Password"));
	//Step16: Enter password in password textfield
		passwordTextfield.sendKeys("chandlerbing");
	//Step17: Locate confirmpassword texfield
		WebElement confirmpasswordTextfield = driver.findElement(By.id("ConfirmPassword"));
	//Step18: Enter Password in "Confirm Password" textfield
		confirmpasswordTextfield.sendKeys("chandlerbing");
	//Step19: Locate register button
		WebElement register = driver.findElement(By.id("register-button"));
	//Step20: Click on "Register" button
		register.click();
		//Verify if "Your registration completed" text is displayed
		//Click on "Continue" button
		//Verify if Home page is displayed
	//Step21: Quit the browser
		driver.quit();

	}

}
