package demoWebShop;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Scenario2 {

	public static void main(String[] args) throws MalformedURLException {
		//Step1: Launch the browser
				WebDriver driver = new ChromeDriver();
		//Step2: Maximize the browser
				driver.manage().window().maximize();
		//Step3: Navigate to application
				driver.navigate().to(new URL("https://demowebshop.tricentis.com/"));
		//Locate Login link
				WebElement loginlink = driver.findElement(By.linkText("Log in"));
		//Click on " Login "  link
				loginlink.click();
		//Verify if Login page is displayed
				String expectedURL="https://demowebshop.tricentis.com/login";
				String actualURL= driver.getCurrentUrl();
				System.out.println(actualURL);
				if(expectedURL.equalsIgnoreCase(actualURL))
				{
					System.out.println("1st Verification successfull");
				}
		//Locate Email textfield
				WebElement emailtextfield = driver.findElement(By.id("Email"));
		//Enter email in "Email " textfield
				emailtextfield.sendKeys("chandlerbing@friends.com");
		//Locate password textfield
				WebElement passwordtextfield = driver.findElement(By.id("Password"));
		//Enter Password in "Password" textfield
				passwordtextfield.sendKeys("chandlerbing");
		//Locate Login button
				WebElement loginbutton = driver.findElement(By.tagName("input"));
		//Click on "Log In" button
				loginbutton.click();
		//Verify if Home page is displayed
				String expectedURL2="https://demowebshop.tricentis.com/";
				String actualURL2= driver.getCurrentUrl();
				System.out.println(actualURL2);
				if(expectedURL.equalsIgnoreCase(actualURL2))
				{
					System.out.println("2nd Verification successfull");
				}
				
	}

}
