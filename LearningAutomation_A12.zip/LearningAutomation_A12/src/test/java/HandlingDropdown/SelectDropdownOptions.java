package HandlingDropdown;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectDropdownOptions {

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		//open the browser
				WebDriver driver = new EdgeDriver();
						
				// maximize
				driver.manage().window().maximize();
						
				//implicit wait
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
						
				//navigate to application via url
				driver.navigate().to(new URL("https://www.amazon.in/"));
								
				//verify the page using title
				System.out.println("The Title of the page is :"+driver.getTitle());
				
				//Locate the All category dropdown
				WebElement dropdown = driver.findElement(By.id("searchDropdownBox"));
						
				//create object for select class
				Select object	= new Select(dropdown);
				
				Thread.sleep(5000);
				//Select and option using index
				object.selectByIndex(39);
				
				Thread.sleep(5000);
				//Select and option using Visible text
				object.selectByVisibleText("Car & Motorbike");
				
				Thread.sleep(5000);
				//Select and option using Value
				object.selectByValue("search-alias=videogames");
				
				//close the browser
				driver.quit();

	}

}
