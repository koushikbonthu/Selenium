package HandlingDropdown;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.Select;

public class verifyDropdown {

	public static void main(String[] args) throws MalformedURLException {
		
		//open the browser
		WebDriver driver = new EdgeDriver();
				
		// maximize
		driver.manage().window().maximize();
				
		//implicit wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
				
		//navigate to application via url
		driver.navigate().to(new URL("https://www.amazon.in/"));
						
		//verify the page using title
		System.out.println("The Title of the page is :"+driver.getTitle());
		
		//Locate the All category dropdown
		WebElement dropdown = driver.findElement(By.id("searchDropdownBox"));
				
		//create object for select class
		Select object	= new Select(dropdown);
		
		//Verify if dropdown is single select or multiple select
		if(object.isMultiple())
		{
			System.out.println("Dropdown is Multiple dropdown");
		}
		else
		{
			System.out.println("Dropdown is Single dropdown");
		}
		
		//call the non static variable
		List<WebElement> alloptions = object.getOptions();
		
		//print the text value
		int count = alloptions.size();
		System.out.println("Count of options is:"+count);
		for(int i=0; i<count; i++)
		{
			String options=alloptions.get(i).getText();
			System.out.println(i+" - "+options);
		}
		
		
		
		//close the browser
		driver.quit();
		
						
		

	}

}
