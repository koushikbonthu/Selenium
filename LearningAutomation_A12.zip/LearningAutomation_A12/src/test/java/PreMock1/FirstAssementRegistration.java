package PreMock1;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class FirstAssementRegistration {

	public static void main(String[] args) throws MalformedURLException {
		
		//Take inputs from user for registering 
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter gender M or F");
		String gender = sc.next();
		
		System.out.println("Enter First Name");
		String firstName = sc.next();
		
		System.out.println("Enter Last Name");
		String lastName = sc.next();
		
		System.out.println("Enter Email");
		String email = sc.next();
		
		System.out.println("Enter Password");
		String password = sc.next();
		
		System.out.println("Enter Password again");
		String cPassword = sc.next();
		
		//Launch the browser
		WebDriver driver = new EdgeDriver();
		
		//Maximize the browser
		driver.manage().window().maximize();
		
		//Navigate to Demo web shop
		driver.navigate().to(new URL("https://demowebshop.tricentis.com/"));
		
		//Locate register link
		WebElement reglink = driver.findElement(By.linkText("Register"));
		
		//Click on Register Link
		reglink.click();
		
		//Verify if navigated to Register page
		String expectedURL="https://demowebshop.tricentis.com/register";
		String actualURL= driver.getCurrentUrl();
		System.out.println(actualURL);
		if(expectedURL.equalsIgnoreCase(actualURL))
		{
			System.out.println("Register Page Verification successfull");
		}
		
		//Locate Male radio button
		WebElement maleradio = driver.findElement(By.id("gender-male"));
		
		//Locate Female radio button
		WebElement femaleradio = driver.findElement(By.id("gender-female"));
		
		switch (gender) {
		case "M":
			 	maleradio.click();
			break;
		case "F":
				femaleradio.click();
			break;

		default:
			System.out.println("Enter M or F only");
			break;
		}
		
		// Locate FirstName texfield
		WebElement firstnameTextfield = driver.findElement(By.id("FirstName"));
		
		//Enter firstname in "First Name " textfield
		firstnameTextfield.sendKeys(firstName);
		
		//Locate LastName texfield
		WebElement lastnameTextfield = driver.findElement(By.id("LastName"));
		
		//Enter lastname in "Last Name " textfield
		lastnameTextfield.sendKeys(lastName);
		
		//Locate email textfield
		WebElement emailTextfield = driver.findElement(By.id("Email"));
		
		//Enter email in "Email " textfield
		emailTextfield.sendKeys(email);
		
		//Locate password texfield
		WebElement passwordTextfield = driver.findElement(By.id("Password"));
		
		//Enter password in password textfield
		passwordTextfield.sendKeys(password);
		
		//Locate confirm password texfield
		WebElement confirmpasswordTextfield = driver.findElement(By.id("ConfirmPassword"));
		
		//Enter Password in "Confirm Password" textfield
		confirmpasswordTextfield.sendKeys(cPassword);
		
		//Locate Register button
		WebElement register = driver.findElement(By.id("register-button"));
		
		//Click on Register button
		register.click();
		
		//Close the browser
		driver.quit();
		
		sc.close();
	}

}
