package PreMock1;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class SecondAssementAddToCart {

	public static void main(String[] args) throws MalformedURLException {
		
		//Take inputs from the user
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Username");
		String username = sc.next();
											
		System.out.println("Enter Password");
		String password = sc.next();
		
		//Launch the browser
		WebDriver driver = new EdgeDriver();
				
		//Maximize the browser
		driver.manage().window().maximize();
				
		//Navigate to Demo web shop
		driver.navigate().to(new URL("https://demowebshop.tricentis.com/"));
		
		//Locate Login link
		WebElement loginlink = driver.findElement(By.linkText("Log in"));
		
		//Click on " Login "  link
		loginlink.click();
		
		//Verify if Login page is displayed
		String expectedURL="https://demowebshop.tricentis.com/login";
		String actualURL= driver.getCurrentUrl();
		System.out.println(actualURL);
		if(expectedURL.equalsIgnoreCase(actualURL))
		{
			System.out.println("Login Page Verification successfull");
		}
		
		//Locate Email textfield
		WebElement emailtextfield = driver.findElement(By.id("Email"));
		
		//Enter email in "Email " textfield
		emailtextfield.sendKeys(username);
		
		//Locate password textfield
		WebElement passwordtextfield = driver.findElement(By.id("Password"));
		
		//Enter Password in "Password" textfield
		passwordtextfield.sendKeys(password);
		
		//Locate Login button
		WebElement loginbutton = driver.findElement(By.xpath("//input[@class='button-1 login-button']"));
		
		//Click on "Log In" button
		loginbutton.click();
		
		//Verify if Home page is displayed
		String expectedURL2="https://demowebshop.tricentis.com/";
		String actualURL2= driver.getCurrentUrl();
		System.out.println(actualURL2);
		if(expectedURL2.equalsIgnoreCase(actualURL2))
		{
			System.out.println("Home page Verification successfull");
		}
		
		//Locate "Books" Category
		WebElement books = driver.findElement(By.linkText("Books"));
		
		//Click on "Books" Category
		books.click();
		
		//Locate 1st product
				WebElement product = driver.findElement(By.linkText("Computing and Internet"));
				
				//Click on "Computing and internet" product
				product.click();
				
				//Locate Login button
				WebElement addToCart = driver.findElement(By.xpath("//input[@id='add-to-cart-button-13']"));
						
				//Click on "Log In" button
				addToCart.click();
				
		
		
		//Locate 2nd product
				WebElement product2 = driver.findElement(By.linkText("Health Book"));
				
				//Click on "Computing and internet" product
				product2.click();
				
				//Locate Login button
				WebElement addToCart2 = driver.findElement(By.xpath("//input[@id='add-to-cart-button-22']"));
						
				//Click on "Log In" button
				addToCart2.click();
				
				
		//Locate 3rd product
				WebElement product3 = driver.findElement(By.linkText("Fiction"));
				
				//Click on "Computing and internet" product
				product3.click();
				
				//Locate Login button
				WebElement addToCart3 = driver.findElement(By.xpath("//input[@id='add-to-cart-button-45']"));
						
				//Click on "Log In" button
				addToCart3.click();		
				
		
		//Locate Cart link
		WebElement cart = driver.findElement(By.linkText("Shopping cart"));
		
		//Click on Cart link
		cart.click();
		
		//Locate product in cart
		List<WebElement> cartProducts = driver.findElements(By.xpath("//td[@class='product']"));
		int count = cartProducts.size();
		System.out.println("Count of products in cart is: "+count);
		
		//Print the product names in the cart
		if (count>1) 
		{
			
			for (int i = 0; i < count; i++) 
			{	
				System.out.println("Products added to cart are: ");
				for (int j = 1; j <= count; j++) 
				{		
				String text = driver.findElement(By.xpath("(//a[@class='product-name'])["+j+"]")).getText();
				System.out.println(j+" "+text);
				}
				break;
			} 
		}
		else if(count==1)
		{
			String text = driver.findElement(By.xpath("//a[@class='product-name']")).getText();
			System.out.println(text+": is the Product added to cart");
		}
		else
		{
			System.out.println("Shopping cart is empty");
		}
		
		//Close the browser
		driver.quit();
		sc.close();

	}

}
