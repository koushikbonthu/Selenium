package PreMock1;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ThirdAssesment {

	public static void main(String[] args) throws InterruptedException, IOException {
		// 1.Open the browser
		WebDriver driver = new EdgeDriver();

		// 2. Maximize the browser
		driver.manage().window().maximize();

		// 3. Navigate to application via url
		driver.navigate().to(new URL("https://www.automationexercise.com/"));

		// 4. Verify the page using title
		System.out.println("Title of page: " + driver.getTitle());

		// 5. Locate the SignUp Link
		WebElement register = driver.findElement(By.xpath("//a[text()=' Signup / Login']"));

		// 6. Click on SignUp element
		register.click();

		// 7. Verify the page using title
		System.out.println("Title of page: " + driver.getTitle());

		// 8. New User SignUp! Information

		// 8.1 Locate Name TextField
		WebElement Name = driver.findElement(By.xpath("//input[@name='name']"));

		// 8.2 Enter Name in Name TextField
		Name.sendKeys("Chandler");

		// 8.3 Locate Email Address TextField in New User SignUp!
		WebElement email = driver.findElement(By.xpath("//input[@name='email' and @data-qa='signup-email']"));

		// 8.4 Enter Name in Name TextField
		email.sendKeys("chandler@gmail.com");

		// 8.5 Locate SignUp Button
		WebElement signup = driver.findElement(By.xpath("//button[text()='Signup']"));

		// 8.6 Click on SignUp Button
		signup.click();

		// 9. Verify the page using title
		System.out.println("Title of page: " + driver.getTitle());

		// Enter Account Information

		// 10. Locate Mr. title radio button
		WebElement Mr = driver.findElement(By.xpath("//input[@id='id_gender1']"));

		// 11. Select Mr. Radio Button
		Mr.click();

		// 12. Locate password TextField
		WebElement password = driver.findElement(By.xpath("//input[@id='password']"));

		// 13. Enter Password in Password TextField
		password.sendKeys("qwertyuiop");

		// 14. Locate the Day DropDown
		WebElement dropdown1 = driver.findElement(By.id("days"));

		// 15. Create object for select class
		Select day = new Select(dropdown1);

		// 16. Select and option using Visible text
		day.selectByVisibleText("5");

		// 17. Locate the Month DropDown
		WebElement dropdown2 = driver.findElement(By.id("months"));

		// 18. Create object for select class
		Select month = new Select(dropdown2);

		// 19. Select and option using Visible text
		month.selectByValue("8");

		// 20. Locate the Year DropDown
		WebElement dropdown3 = driver.findElement(By.id("years"));

		// 21. Create object for select class
		Select year = new Select(dropdown3);

		Thread.sleep(1000);
		// 22. Select and option using Visible text
		year.selectByValue("1997");

		// Scroll Till Address Information is visible
		JavascriptExecutor js = (JavascriptExecutor) driver;

		// 23. Locate Address Information text
		By elementLocator = By.xpath("//input[@id='state']");
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(elementLocator));

		// 24. Scroll Till Address Information Text is visible
		js.executeScript("arguments[0].scrollIntoView(false)", element);
		wait.until(ExpectedConditions.visibilityOf(element));

		// 25. Locate First name TextField
		WebElement firstname = driver.findElement(By.xpath("//input[@id='first_name']"));

		// 26. Enter First Name
		firstname.sendKeys("Chandler");

		// 27. Locate Last name TextField
		WebElement lastname = driver.findElement(By.xpath("//input[@id='last_name']"));

		// 28. Enter Last Name
		lastname.sendKeys("Bing");

		// 29. Locate Address TextField
		WebElement address = driver.findElement(By.xpath("//input[@id='address1']"));

		// 30. Enter Address in Address TextField
		address.sendKeys("Central Perk");

		// 31. Locate Country DropDown
		WebElement dropdown4 = driver.findElement(By.id("country"));

		// 32. Create object for select class
		Select country = new Select(dropdown4);

		// 33. Select and option using Visible text
		country.selectByVisibleText("India");

		// Scroll Till Create Account button is visible

		// 34. Locate Create Account button
		By elementLocator2 = By.xpath("//button[text()='Create Account']");
		WebElement createAccount = wait.until(ExpectedConditions.presenceOfElementLocated(elementLocator2));

		// 35. Scroll Till Create Account button is visible
		js.executeScript("arguments[0].scrollIntoView(false)", createAccount);
		wait.until(ExpectedConditions.visibilityOf(createAccount));

		// 36. Locate State TextField
		WebElement state = driver.findElement(By.xpath("//input[@id='state']"));

		// 37. Enter State in State TextField
		state.sendKeys("New York");

		// 38. Locate City TextField
		WebElement city = driver.findElement(By.xpath("//input[@id='city']"));

		// 39. Enter State in State TextField
		city.sendKeys("New York- City");

		// 40. Locate ZipCode TextField
		WebElement zipcode = driver.findElement(By.xpath("//input[@id='zipcode']"));

		// 41. Enter State in State TextField
		zipcode.sendKeys("3366-6633");

		// 42. Locate Mobile TextField
		WebElement mobile = driver.findElement(By.xpath("//input[@id='mobile_number']"));

		// 43. Enter State in State TextField
		mobile.sendKeys("963963936");

		// 44. Click on Create Account button
		createAccount.click();

		// Verify Account is created

		// 45. Locate account created text
		WebElement success = driver.findElement(By.xpath("//b[text()='Account Created!']"));

		if (success.isDisplayed()) {
			System.out.println("Title of page: " + driver.getTitle());
			TakesScreenshot ts = (TakesScreenshot) driver;
			File temp = ts.getScreenshotAs(OutputType.FILE);
			File permanent = new File("./Screenshots/AssessmentScreenshot.png");
			FileHandler.copy(temp, permanent);
		}

		// 46. Close the browser
		driver.quit();

	}

}
