package HandlingPopUp;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class HandlingFileUpload {

	public static void main(String[] args) throws MalformedURLException {
		// Launch the browser
				WebDriver driver = new EdgeDriver();

				// Maximize the browser
				driver.manage().window().maximize();

				// Navigate to Demo web shop
				driver.navigate().to(new URL("https://automationexercise.com/"));

				// Verify the page URL
				String expectedURL = "https://magento.softwaretestingboard.com/";
				String actualURL = driver.getCurrentUrl();
				System.out.println(actualURL);
				if (expectedURL.equalsIgnoreCase(actualURL)) {
					System.out.println("Page Verification successfull");
				}
				
				//Locate "Contact Us" link
				WebElement contactUs = driver.findElement(By.partialLinkText("Contact"));
				
				//Click on contact us link
				contactUs.click();
				
				//Locate choose file button
				WebElement chooseFile = driver.findElement(By.name("upload_file"));
				
				//Upload Absolute File Path
				File dataFile = new File("./Data/Sample.txt");
				String absolutePath = dataFile.getAbsolutePath();
				chooseFile.sendKeys(absolutePath);
				
				//Close the browser
				driver.quit();
	}

}
