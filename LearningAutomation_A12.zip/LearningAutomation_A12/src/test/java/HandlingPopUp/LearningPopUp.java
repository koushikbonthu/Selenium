package HandlingPopUp;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class LearningPopUp {

	public static void main(String[] args) throws MalformedURLException {
		// Launch the browser
		WebDriver driver = new EdgeDriver();

		// Maximize the browser
		driver.manage().window().maximize();

		// Navigate to Demo web shop
		driver.navigate().to(new URL("https://the-internet.herokuapp.com/javascript_alerts"));

		// Identify the JS Alert element
		WebElement popupBtn1 = driver.findElement(By.xpath("//button[@onclick='jsAlert()']"));
		popupBtn1.click();

		// Get Text from PopUp
		System.out.println(driver.switchTo().alert().getText());

		// Click on "Ok" button
		driver.switchTo().alert().accept();

		// Identify the JS COnfirm element
		WebElement popupBtn2 = driver.findElement(By.xpath("//button[@onclick='jsConfirm()']"));
		popupBtn2.click();

		// Get Text from PopUp
		System.out.println(driver.switchTo().alert().getText());

		// Click on "Ok" button
		driver.switchTo().alert().accept();

		// Identify the JS Prompt element
		WebElement popupBtn3 = driver.findElement(By.xpath("//button[@onclick='jsPrompt()']"));
		popupBtn3.click();

		// Get Text from PopUp
		System.out.println(driver.switchTo().alert().getText());

		// Enter the data
		driver.switchTo().alert().sendKeys("Ananth");

		// Click on "Ok" button
		driver.switchTo().alert().accept();

		// Close the browser
		driver.quit();

	}

}
