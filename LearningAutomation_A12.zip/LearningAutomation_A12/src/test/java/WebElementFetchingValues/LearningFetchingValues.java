package WebElementFetchingValues;


import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class LearningFetchingValues {

	public static void main(String[] args) throws MalformedURLException {
		
		//Launch the browser
		WebDriver driver = new EdgeDriver();
		
		//Maximize the browser
		driver.manage().window().maximize();
		
		//Navigate to URL
		driver.navigate().to(new URL("https://www.saucedemo.com/"));
		
		//Locate the element
		WebElement logo = driver.findElement(By.xpath("//div[contains(text(),'Sw')]"));
		
		//Validate------------displayed and enabled
		if (logo.isDisplayed() && logo.isEnabled()) {
			System.out.println("Logo is Displayed and enabled");
		} else {
			System.out.println("Logo is not Displayed or enabled");
		}
		
		//Fetch the Text value
		String text =  logo.getText();
		
		//Fetch the Tagname
		String Tag = logo.getTagName();
		
		//Fetch Attribute value
		@SuppressWarnings("deprecation")
		String AttributeValue= logo.getAttribute("class");
		
		//Fetch css Value
		String CssValue = logo.getCssValue("unicode-bidi");
		
		//Fetch Size
		Dimension size = logo.getSize();
		
		//fetch Location
		Point location = logo.getLocation();
		
		//Printing Values
		System.out.println("Text is: "+text);
		System.out.println("-----------------------------------------");
		System.out.println("Tag name is: "+Tag);
		System.out.println("-----------------------------------------");
		System.out.println("Attribute value is: "+AttributeValue);
		System.out.println("-----------------------------------------");
		System.out.println("Css value for unicode-bidi is: "+CssValue);
		System.out.println("-----------------------------------------");
		System.out.println("Size of logo is: "+size);
		System.out.println("Width of logo is: "+size.getWidth());
		System.out.println("Height of logo is: "+size.getHeight());
		System.out.println("-----------------------------------------");
		System.out.println("Logo Location is: "+location);
		System.out.println("Logo X is: "+location.getX());
		System.out.println("Logo Y is: "+location.getY());
		
		
		
		//Close the browser
		driver.quit();

	}

}
