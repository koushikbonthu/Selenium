package DataDrivenTesting;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class HandlingPropertiesFile {

	public static void main(String[] args) throws IOException {

		String data = readData("url");
		System.out.println(data);
		String data1 = readData("username");
		System.out.println(data1);
		String data2 = readData("password");
		System.out.println(data2);
		
		writeData("Hi", "hello");
		writeData("HiHi", "hello0000");

	}
	
	public static String readData(String key) throws IOException
	{
		// 1. convert the external file into java readable file
	FileInputStream filr = new FileInputStream("./src/test/resources/commonData.properties");
	
	// 2. create an object for properties class
	Properties propertyobj=new Properties();
	
	
	// 3. load the properties
	propertyobj.load(filr);
	
	// read the data
	return propertyobj.getProperty(key);
		
	}
	
	public static void writeData(String newkey, String newvalue) throws IOException
	{
		// 1. convert the external file into java readable file
	FileInputStream fis = new FileInputStream("./src/test/resources/commonData.properties");
	
	// 2. create an object for properties class
	Properties propertyobj = new Properties();
	
	
	// 3. load the properties
	propertyobj.load(fis);
	
	// 4. Put the new data inside properties file
	propertyobj.put(newkey, newvalue);
	
	//5. Convert java readable into external file
	FileOutputStream fos = new FileOutputStream("./src/test/resources/commonData.properties");
	
	//6. Store the new data
	propertyobj.store(fos, "***********Updated new key and value*******");
	System.out.println("writeData success");
		
	}

}
