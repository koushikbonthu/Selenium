package DataDrivenTesting;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment {

	public static void main(String[] args) throws IOException {
		// Launch the browser
		WebDriver driver = new ChromeDriver();

		// maximize the browser
		driver.manage().window().maximize();

		// Navigate to Application
		String data = readData("url");
		driver.get(data);
		// System.out.println(data);

		// Locate Username textfield
		WebElement username = driver.findElement(By.xpath("//input[@id='user-name']"));
		String data1 = readData("username");
		username.sendKeys(data1);
		// System.out.println(data1);

		// Locate password textfield
		WebElement password = driver.findElement(By.xpath("//input[@id='password']"));
		String data2 = readData("password");
		password.sendKeys(data2);
		// System.out.println(data2);

		// Locate login button
		WebElement login = driver.findElement(By.xpath("//input[@class='submit-button btn_action']"));
		login.click();

		// Locate element1
		WebElement element1 = driver.findElement(By.xpath("//div[contains(text(),'Sauce Labs Backpack')]"));
		// Fetch Text value
		String text1 = element1.getText();
		writeData("First_Product:", text1);

		// Locate element2
		WebElement element2 = driver.findElement(By.xpath("//div[contains(text(),'Sauce Labs Bike Light')]"));
		// Fetch Text value
		String text2 = element2.getText();
		writeData("Second_Product:", text2);

		// Locate element3
		WebElement element3 = driver.findElement(By.xpath("//div[contains(text(),'Sauce Labs Bolt T-Shirt')]"));
		// Fetch Text value
		String text3 = element3.getText();
		writeData("Third_Product:", text3);
		
		//Close the Browser
		driver.quit();

	}

	public static String readData(String key) throws IOException {
		// 1. convert the external file into java readable file
		FileInputStream filr = new FileInputStream("./src/test/resources/commonData.properties");

		// 2. create an object for properties class
		Properties propertyobj = new Properties();

		// 3. load the properties
		propertyobj.load(filr);

		// read the data
		return propertyobj.getProperty(key);

	}

	public static void writeData(String newkey, String newvalue) throws IOException {
		// 1. convert the external file into java readable file
		FileInputStream fis = new FileInputStream("./src/test/resources/commonData.properties");

		// 2. create an object for properties class
		Properties propertyobj = new Properties();

		// 3. load the properties
		propertyobj.load(fis);

		// 4. Put the new data inside properties file
		propertyobj.put(newkey, newvalue);

		// 5. Convert java readable into external file
		FileOutputStream fos = new FileOutputStream("./src/test/resources/commonData.properties");

		// 6. Store the new data
		propertyobj.store(fos, "***********Updated new Products and its text*******");
		System.out.println("writeData success");

	} 

}
