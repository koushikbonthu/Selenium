
package DataDrivenTesting;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class HandlingExcelFile {

	public static void main(String[] args) throws IOException {

		 //System.out.println(readData("LoginData", 1, 0));
		 //System.out.println(readData("LoginData", 1, 1));

		//writeData_Existing("LoginData", 1, 1, "secret_sauce");
		
		//writeData_Existing("LoginData", 0, 2, "Status");
		
		//writeData_Existing("LoginData", 1, 2, "Swag Labs");

		readDataSpecificRow("RegisterData", 0);

		readDataSpecificColumn("RegisterData", 0);

		readDataAll("RegisterData", 0);

	}

	public static String readData(String Sheet, int row, int cell) throws IOException {

		// 1. Convert the external file into java readable using fileInputStream class.
		FileInputStream fis = new FileInputStream("./src/test/resources/SeleniumBacthA12.xlsx");

		// 2. Create a workbook using workbook factory.
		Workbook book = WorkbookFactory.create(fis);

		// 3. Read the data using using workbook sheet, row and column(cell).
		String data = book.getSheet(Sheet).getRow(row).getCell(cell).getStringCellValue();

		System.out.println("Read Data Success");

		return data;

	}

	public static void writeData_Existing(String Sheet, int row, int cell, String data) throws IOException {

		// 1. Convert the external file into java readable using fileInputStream class.
		FileInputStream fis = new FileInputStream("./src/test/resources/SeleniumBacthA12.xlsx");

		// 2. Create a workbook using workbook factory.
		Workbook book = WorkbookFactory.create(fis);

		// 3. Write the data in existing Sheet and Row
		book.getSheet(Sheet).getRow(row).createCell(cell).setCellValue(data);

		// 4. Convert java readable into external file
		FileOutputStream fos = new FileOutputStream("./src/test/resources/SeleniumBacthA12.xlsx");

		// 5. Call the write method
		book.write(fos);

		System.out.println("Write Data Success");

	}

	public static void readDataSpecificRow(String Sheet, int row) throws IOException {

		// 1. Convert the external file into java readable using fileInputStream class.
		FileInputStream fis = new FileInputStream("./src/test/resources/SeleniumBacthA12.xlsx");

		// 2. Create a workbook using workbook factory.
		Workbook book = WorkbookFactory.create(fis);

		int lastcellvalue = book.getSheet(Sheet).getRow(row).getLastCellNum();

		System.out.println("Last Column value is:" + lastcellvalue);

		// 3. Read the data using using workbook sheet, row and column(cell).
		for (int i = 0; i < lastcellvalue; i++) {
			String data = book.getSheet(Sheet).getRow(row).getCell(i).getStringCellValue();
			System.out.print(data+", ");
		}
		System.out.println();
		System.out.println("*********************************************************");

	}

	public static void readDataSpecificColumn(String Sheet, int cell) throws IOException {

		// 1. Convert the external file into java readable using fileInputStream class.
		FileInputStream fis = new FileInputStream("./src/test/resources/SeleniumBacthA12.xlsx");

		// 2. Create a workbook using workbook factory.
		Workbook book = WorkbookFactory.create(fis);

		int lastrowvalue = book.getSheet(Sheet).getLastRowNum();

		System.out.println("Last Row value is:" + lastrowvalue);

		// 3. Read the data using using workbook sheet, row and column(cell).
		for (int i = 1; i <= lastrowvalue; i++) {
			String data = book.getSheet(Sheet).getRow(i).getCell(cell).getStringCellValue();
			System.out.println(data);
		}
		System.out.println("*********************************************************");
	}

	public static void readDataAll(String Sheet, int row) throws IOException {

		// 1. Convert the external file into java readable using fileInputStream class.
		FileInputStream fis = new FileInputStream("./src/test/resources/SeleniumBacthA12.xlsx");

		// 2. Create a workbook using workbook factory.
		Workbook book = WorkbookFactory.create(fis);

		int lastcellvalue = book.getSheet(Sheet).getRow(row).getLastCellNum();
		System.out.println("Last Column value is:" + lastcellvalue);
		int lastrowvalue = book.getSheet(Sheet).getLastRowNum();
		System.out.println("Last Row value is:" + lastrowvalue);

		// 3. Read the data using using workbook sheet, row and column(cell).
		System.out.println(lastcellvalue * lastrowvalue + " Values are : ");
		for (int i = 1; i <= lastrowvalue; i++) {
			for (int j = 0; j < lastcellvalue; j++) {

				String data = book.getSheet(Sheet).getRow(i).getCell(j).getStringCellValue();
				System.out.print(data+", ");
			}
			System.out.println();
		}
		System.out.println("*********************************************************");
	}
}
