package DataDrivenTesting;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment2 {

	public static void main(String[] args) throws IOException {
		// Launch the browser
		WebDriver driver = new ChromeDriver();

		// maximize the browser
		driver.manage().window().maximize();

		// Navigate to Application
		String data = readData("LoginData", 1, 0);
		driver.get(data);
		// System.out.println(data);

		// Locate Username textfield
		WebElement username = driver.findElement(By.xpath("//input[@id='user-name']"));
		String data1 = readData("LoginData", 1, 1);
		username.sendKeys(data1);

		// Locate password textfield
		WebElement password = driver.findElement(By.xpath("//input[@id='password']"));
		String data2 = readData("LoginData", 1, 2);
		password.sendKeys(data2);

		// Locate login button
		WebElement login = driver.findElement(By.xpath("//input[@class='submit-button btn_action']"));
		login.click();
		
		//Verify the page
		System.out.println(driver.getTitle());
		
		// Close the browser
		driver.quit();
	}

	public static String readData(String Sheet, int row, int cell) throws IOException {

		// 1. Convert the external file into java readable using fileInputStream class.
		FileInputStream fis = new FileInputStream("./src/test/resources/SeleniumBacthA12.xlsx");

		// 2. Create a workbook using workbook factory.
		Workbook book = WorkbookFactory.create(fis);

		// 3. Read the data using using workbook sheet, row and column(cell).
		String data = book.getSheet(Sheet).getRow(row).getCell(cell).getStringCellValue();

		System.out.println("Read Data Success");

		return data;

	}

	public static void writeData_Existing(String Sheet, int row, int cell, String data) throws IOException {

		System.out.println("Write Data Success");
		// 1. Convert the external file into java readable using fileInputStream class.
		FileInputStream fis = new FileInputStream("./src/test/resources/SeleniumBacthA12.xlsx");

		// 2. Create a workbook using workbook factory.
		Workbook book = WorkbookFactory.create(fis);

		// 3. Write the data in existing Sheet and Row
		book.getSheet(Sheet).getRow(row).createCell(cell).setCellValue(data);

		// 4. Convert java readable into external file
		FileOutputStream fos = new FileOutputStream("./src/test/resources/SeleniumBacthA12.xlsx");

		// 5. Call the write method
		book.write(fos);

	}

}
