package HandlingKeyboardActions;

import java.awt.AWTException;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

public class UsingActionsClass {

	public static void main(String[] args) throws MalformedURLException, AWTException {

		// Launch the browser
		WebDriver driver = new EdgeDriver();

		// Maximize the browser
		driver.manage().window().maximize();

		// Navigate to Demo web shop
		driver.navigate().to(new URL("https://demowebshop.tricentis.com/"));

		// Create object for Actions class
		Actions object = new Actions(driver);

		// Call SendKeys method and perform action
		object.sendKeys(Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB, Keys.TAB,"computer",Keys.ENTER).perform();
	}

}
