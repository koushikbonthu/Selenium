package HandlingKeyboardActions;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.net.URL;
import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class PracticeScenario {

	public static void main(String[] args) throws Exception {
		Scanner sc = new Scanner(System.in);

		// Step 1: Take input from user
		System.out.print("Enter username: ");
		String username = sc.nextLine();

		Thread.sleep(5000); 

		// Step 2: Use Robot to type each character
		Robot robot = new Robot();

		// Launch the browser
		WebDriver driver = new EdgeDriver();

		// Maximize the browser
		driver.manage().window().maximize();

		// Navigate to Demo web shop
		driver.navigate().to(new URL("https://google.com/"));
		
		Thread.sleep(10000);//InCase any PopUps to handle them manually
		
		for (char c : username.toCharArray()) {
			typeChar(robot, c);
			Thread.sleep(100);
		}
		
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		
		System.out.println("Username typed successfully.");
		sc.close();
	}

	// Method to type characters using Robot
	public static void typeChar(Robot robot, char c) throws Exception {
		boolean upperCase = Character.isUpperCase(c);
		int keyCode = KeyEvent.getExtendedKeyCodeForChar(c);

		if (keyCode == KeyEvent.VK_UNDEFINED) {
			throw new Exception("Cannot type character: " + c);
		}

		if (upperCase) {
			robot.keyPress(KeyEvent.VK_SHIFT);
		}

		robot.keyPress(keyCode);
		robot.keyRelease(keyCode);

		if (upperCase) {
			robot.keyRelease(KeyEvent.VK_SHIFT);
		}
	}
}
