package automationExercises;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class TestCase1 {

	public static void main(String[] args) throws MalformedURLException {
		// Launch the browser
		WebDriver driver = new EdgeDriver();

		// Maximize the browser
		driver.manage().window().maximize();

		// Navigate to Demo web shop
		driver.navigate().to(new URL("https://automationexercise.com/"));

		// Verify the page URL
		String expectedURL = "https://magento.softwaretestingboard.com/";
		String actualURL = driver.getCurrentUrl();
		System.out.println(actualURL);
		if (expectedURL.equalsIgnoreCase(actualURL)) {
			System.out.println("Page Verification successfull");
		}

		// Locate signup link
		WebElement signup = driver.findElement(By.xpath("//a[text()=' Signup / Login']"));

		// click on signup link
		signup.click();

		// Locate signup link
		WebElement newsignup = driver.findElement(By.xpath("//h2[text()='New User Signup!']"));

		// Verify if visible
		if (newsignup.isDisplayed()) {
			System.out.println("Verification successfull");
		}
	}

}
