package LearningFlags;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class DependsOnMethodFlag {
	@Test(dependsOnMethods ="Milds" )
	public void KINGLigths() {
		Reporter.log("KINGLigths", true);
	}
	
	@Test
	public void Milds() {
		Reporter.log("Milds", true);
	}
}
