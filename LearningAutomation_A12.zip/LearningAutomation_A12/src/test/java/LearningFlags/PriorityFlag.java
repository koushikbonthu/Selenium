package LearningFlags;


import org.testng.Reporter;
import org.testng.annotations.Test;

public class PriorityFlag {

	@Test(priority = 50)
	public void Apple() {
		Reporter.log("Apple", true);
	}
	
	@Test(priority = 0)
	public void Samsung() {
		Reporter.log("Samsung", true);
	}
	
	@Test(priority = -1)
	public void Blackberry() {
		Reporter.log("Blackberry", true);
	}
	
	
	
}
