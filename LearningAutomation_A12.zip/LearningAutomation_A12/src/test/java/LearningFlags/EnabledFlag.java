package LearningFlags;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class EnabledFlag {

	@Test(enabled = false)
	public void Kings() {
		Reporter.log("Kings", true);
	}
	
	@Test(enabled = true)
	public void KINGLigths() {
		Reporter.log("KINGLigths", true);
	}
	
	@Test(enabled = true)
	public void Milds() {
		Reporter.log("Milds", true);
	}
	
	
	
}
