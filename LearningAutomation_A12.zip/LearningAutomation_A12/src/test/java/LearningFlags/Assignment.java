package LearningFlags;

import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Assignment {
	
	@Test(priority = 1)
	public void SQL() {
		Reporter.log("SQL", true);
	}

	@Test(priority = 2, invocationCount = 2)
	public void ManualTesting() {
		Reporter.log("ManualTesting", true);
	}

	@Test(priority = 3)
	public void Java() {
		Reporter.log("Java", true);
	}

	@Test(dependsOnMethods = "Java")
	public void Selenium() {
		Reporter.log("Selenium", true);
	}

	@Test(enabled = false)
	public void API() {
		Reporter.log("API", true);
	}
	@BeforeMethod
	public void Pre_Mock() {
		Reporter.log("Pre_Mock", true);
	}

	@AfterMethod
	public  void final_mock() {
		Reporter.log("final_mock", true);
	}

}
