package LearningFlags;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class InvocationCountFlag {

	@Test(invocationCount = 5)
	public void Milds() {
		Reporter.log("Milds", true);
	}
	
}
