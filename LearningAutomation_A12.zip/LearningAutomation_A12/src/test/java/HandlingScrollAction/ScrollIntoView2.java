package HandlingScrollAction;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ScrollIntoView2 {

		public static void main(String[] args) throws MalformedURLException, InterruptedException {
			WebDriver driver = new EdgeDriver();
			driver.manage().window().maximize();
			driver.navigate().to(new URL("https://www.decathlon.in/"));
			System.out.println("Page title: " + driver.getTitle());

			JavascriptExecutor js = (JavascriptExecutor) driver;

			// Scroll slowly to bottom to trigger lazy load
			for (int i = 0; i < 8; i++) {
				js.executeScript("window.scrollBy(0, 1000)");
				Thread.sleep(1000);
			}

			// xpath to locate element
			By elementLocator = By.xpath("//h2[contains(text(), 'After Sales Services')]");
			
			WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
			WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(elementLocator));
			
			// Scroll to element
			js.executeScript("arguments[0].scrollIntoView(true)",element);
			
			wait.until(ExpectedConditions.visibilityOf(element));
			System.out.println("Element is now visible!");

			//driver.quit();

	}

}
