package HandlingScrollAction;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class ScrollByVertical {

	public static void main(String[] args) throws MalformedURLException {
				//open the browser
				WebDriver driver = new EdgeDriver();
						
				// maximize
				driver.manage().window().maximize();
						
				//implicit wait
				driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
						
				//navigate to application via url
				driver.navigate().to(new URL("https://www.decathlon.in/"));
								
				//verify the page using title
				System.out.println("The Title of the page is :"+driver.getTitle());
				
				//Perform Scroll Action ----> ScrollBy
				//perform typecast
				JavascriptExecutor js = (JavascriptExecutor) driver;
				
				js.executeScript("window.scrollBy(0,1000)");
				js.executeScript("window.scrollBy(0,1000)");
				js.executeScript("window.scrollBy(0,1000)");
				
				//Close browser
				driver.quit();
	
	}

}
