package HandlingScrollAction;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ScrollIntoView {

	public static void main(String[] args) throws MalformedURLException {
		//open the browser
		WebDriver driver = new EdgeDriver();
				
		// maximize
		driver.manage().window().maximize();
				
		//implicit wait
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
				
		//navigate to application via url
		driver.navigate().to(new URL("https://www.decathlon.in/"));
						
		//verify the page using title
		System.out.println("The Title of the page is :"+driver.getTitle());
		
		
		
		
		
		
		//Locate element to scroll
		WebElement element = driver.findElement(By.xpath("//h2[text()='BUDGET SPORT SHOPPING']"));
		
			
				
		//Perform Scroll Action ----> ScrollIntoView
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		/*//Wait statement
				WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		//Expected condition
			wait.until(ExpectedConditions.visibilityOf(element));
		*/	
			js.executeScript("arguments[0].scrollIntoView(true)",element);
			
		

	}

}
