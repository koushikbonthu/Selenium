package HandlingWebTable;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class FetchDataFromWebTable {

	public static void main(String[] args) throws MalformedURLException {
		// Launch the browser
		WebDriver driver = new EdgeDriver();

		// Maximize the browser
		driver.manage().window().maximize();

		// Navigate to Demo web shop
		driver.navigate().to(new URL("https://www.tutorialspoint.com/selenium/practice/webtables.php"));

		
		
		
		// Locate first employee first Name
		WebElement firstEmployeeName = driver.findElement(By.xpath("//table/tbody/tr[1]/td[1]"));

		// Fetch data from element
		String text = firstEmployeeName.getText();
		System.out.println(text);

		System.out.println("--------------------------------------------------------");
		// Locate all the employee first names
		List<WebElement> list = driver.findElements(By.xpath("//table/tbody/tr/td[@scope='row']"));
		int count = list.size();

		// Fetch the names of employees
		for (int i = 0; i < count; i++) {
			String name = list.get(i).getText();
			System.out.println(name);
		}

		System.out.println("----------------------------------------------");
		// Locate third employee details
		List<WebElement> list2 = driver.findElements(By.xpath("//table/tbody/tr[3]/td"));
		int count2 = list2.size();

		// Fetch the details of third employee
		for (int i = 0; i < count2; i++) {
			String name2 = list2.get(i).getText();
			System.out.println(name2);
		}
		
		System.out.println("----------------------------------------------");
		// Locate All employee all details in a single line 
		List<WebElement> list3 = driver.findElements(By.xpath("//table/tbody/tr"));
		int count3 = list3.size();

		// Fetch the details of third employee
		for (int i = 0; i < count3; i++) {
			String name2 = list3.get(i).getText();
			System.out.println(name2);

		}
		System.out.println("----------------------------------------------");
		// Locate All employee all details line by line
		List<WebElement> list4 = driver.findElements(By.xpath("//table/tbody/tr/td"));
		int count4 = list4.size();
		
		// Fetch the details of third employee
		for (int i = 0; i < count4; i++) {
			String name2 = list4.get(i).getText();
			System.out.println(name2);
			
		}
		// Close the browser
		driver.quit();
	}

}
