package Synchronization;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LaerningExplicitWait {

	public static void main(String[] args) throws MalformedURLException {
		//Launch the browser
		WebDriver driver = new EdgeDriver();
		
		//Maximize the browser
		driver.manage().window().maximize();
		
		//Navigate to URL
		driver.navigate().to(new URL("https://www.shoppersstack.com/"));
		
		//Verify the page
		System.out.println("Title is: "+driver.getTitle());
		
		//Wait statement
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		
		//Expected condition
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#loginBtn")));
		
		//Locate the element
		WebElement loginButton = driver.findElement(By.cssSelector("#loginBtn"));
		
		//Click on element
		loginButton.click();
		
		//Close the browser
		driver.quit();
	}

}
