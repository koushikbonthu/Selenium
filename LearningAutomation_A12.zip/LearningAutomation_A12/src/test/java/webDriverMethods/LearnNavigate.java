package webDriverMethods;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnNavigate {

	public static void main(String[] args) throws MalformedURLException {
		//Launch the browser
		WebDriver driver = new ChromeDriver();
		//Step2: Maximize the browser
		driver.manage().window().maximize();
		//Navigate to 1st application
		driver.navigate().to("https://www.youtube.com/");
		//Navigate to 2nd application
		driver.navigate().to(new URL("https://www.saucedemo.com/v1/"));
		//Navigate to 3rd application
		driver.get("https://demowebshop.tricentis.com/");
		//Navigate to 2nd application
		driver.navigate().back();
		//Forward to 3rd application
		driver.navigate().forward();
		//Reload the page
		driver.navigate().refresh();
		//Quit the browser
		driver.quit();
	}

}
