package webDriverMethods;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriver.Options;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnManage {

	public static void main(String[] args) {
		//Step1: Launch the browser
				WebDriver driver = new ChromeDriver();
				//Step2: Maximize the browser
				//driver.manage().window().maximize();
				//Step3: Minimize the browser
				//driver.manage().window().minimize();
				//Step4: Full-screen the browser
				//driver.manage().window().fullscreen();
				//Step5: Set Size of the browser
				driver.manage().window().setSize(new Dimension(600, 600));
				//Step6: Set position of the browser
				
				driver.manage().window().setPosition(new Point(300,80));
				//Step7: Navigate to Swag-labs
				driver.get("https://www.saucedemo.com/v1/");
				//Step8: Close the browser
				
				System.out.println(driver.manage().window().getSize());
				System.out.println(driver.manage().window().getPosition());
				driver.close();
				
	}

}
