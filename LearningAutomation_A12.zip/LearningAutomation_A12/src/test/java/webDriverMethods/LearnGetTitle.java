package webDriverMethods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnGetTitle {

	public static void main(String[] args) {
		//Step1: Open the browser-Chrome
				WebDriver driver =	new ChromeDriver();
		//Step2: Navigate to application via URL
				driver.get("https://www.saucedemo.com/v1/");
		//Step3: Verify with title
				String actualTitle= driver.getTitle();
				System.out.println(actualTitle);
				String expectedTitle="Swag Labs";
				if(expectedTitle.equalsIgnoreCase(actualTitle))
				{
					System.out.println("Verification succesfull");
				}
		//Step4: Close the browser
				driver.close();

	}

}
