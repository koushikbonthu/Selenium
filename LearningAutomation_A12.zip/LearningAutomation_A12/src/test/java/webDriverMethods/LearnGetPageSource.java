package webDriverMethods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnGetPageSource {

	public static void main(String[] args) {
		//Step1: Open the browser-Chrome
				WebDriver driver =	new ChromeDriver();
		//Step2: Navigate to application via URL
				driver.get("https://www.saucedemo.com/v1/");
		//Step3: Fetch source code
				System.out.println(driver.getPageSource());
		//Step4: Close the browser
				driver.close();

	}

}
