package webDriverMethods;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnGetCurrentURL {

	public static void main(String[] args) {
		//Step1: Open the browser-Chrome
				WebDriver driver =	new ChromeDriver();
		//Step2: Navigate to application via URL
				driver.get("https://www.saucedemo.com/v1/");
		//Step3: Verify with URL
				String expectedURL="https://www.saucedemo.com/v1/";
				String actualURL= driver.getCurrentUrl();
				System.out.println(actualURL);
				if(expectedURL.equalsIgnoreCase(actualURL))
				{
					System.out.println("Verification successfull");
				}
		//Step4: Close the browser
				driver.close();

	}

}
