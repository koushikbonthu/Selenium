package LearningBatchExecution;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;

public class TestClass_01 extends BaseConfig {
	
	@Test
	
	public  void order_computerDesktopPrdTest1() throws InterruptedException  {
   
		WebElement  element1 = driver.findElement(By.xpath("//div[@class='header-menu']/ul[@class='top-menu']/li[2]/a"));
		element1.click();
		WebElement desktop = driver.findElement(By.xpath("//h2/a[contains(@title,'Show products in category Desktops')]"));
		desktop.click();
		WebElement addToCart = driver.findElement(By.xpath("//input[contains(@onclick,'72')]"));
		addToCart.click();
		Reporter.log("Build your own cheap computer  successfully: Test01", true);
	}
	
	
}
