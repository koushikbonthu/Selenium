package LearningBatchExecution;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;

import PageRepository.DWSLoginPage;

public class BaseConfig {

	public WebDriver driver;

	@BeforeClass
	public void browserSetup() {

		driver = new ChromeDriver();
		Reporter.log("Browser opened successfully", true);

		driver.get("https://demowebshop.tricentis.com/");
		Reporter.log("Nav to Application successfully", true);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(3));
	}

	@BeforeMethod
	public void login() throws InterruptedException {
		DWSLoginPage obj = new DWSLoginPage(driver);

		obj.getloginlink().click();
		obj.getemail().sendKeys("Chandlerbing@friends.com");
		obj.getpassword().sendKeys("chandlerbing");
		obj.getLoginButton().click();

		Thread.sleep(5000);
		Reporter.log("login successfully", true);

	}

	@AfterMethod
	public void logout() {
		Reporter.log("log out successfully", true);
	}

	@AfterClass
	public void browserTermination() {
		driver.close();
		Reporter.log("browser close successfully", true);
	}

}
