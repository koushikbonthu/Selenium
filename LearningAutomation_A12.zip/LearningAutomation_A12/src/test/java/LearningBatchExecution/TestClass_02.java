package LearningBatchExecution;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class TestClass_02 extends BaseConfig{
	
	@Test
	
	public  void order_computerDesktopPrdTest2()  throws InterruptedException  {
   
		WebElement  element1 = driver.findElement(By.xpath("//div[@class='header-menu']/ul[@class='top-menu']/li[2]/a"));
		element1.click();
		WebElement desktop = driver.findElement(By.xpath("//h2/a[contains(@title,'Show products in category Desktops')]"));
		desktop.click();
		WebElement addToCart = driver.findElement(By.xpath("//input[contains(@onclick,'16')]"));
		addToCart.click();
		Reporter.log("Build your own computer  successfully: Test02", true);
	}
	
}
