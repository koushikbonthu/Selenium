package LearningAnnotations;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
public class Exmple1 {
	WebDriver driver;
		@BeforeClass
	    public  void browserSetup() {
			
			
		
	       driver=new ChromeDriver();
			Reporter.log("Browser opened successfully", true);	
			
			driver.get("https://demowebshop.tricentis.com/");
			Reporter.log("Nav to Application successfully", true);
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5000));
		}
		
		@BeforeMethod
		public  void login() {
			WebElement Login_Linktext=driver.findElement(By.linkText("Log in"));
			Login_Linktext.click();
			WebElement Email_textfiled=driver.findElement(By.id("Email"));
			Email_textfiled.sendKeys("rajmediboina@gmail.com");
			WebElement password_textfiled =driver.findElement(By.id("Password"));
			 password_textfiled.sendKeys("Raju@1999");
			 WebElement Login_button =driver.findElement(By.cssSelector("input[value='Log in']"));
			 Login_button.click();
			Reporter.log("login successfully", true);
		}
		
		@Test
		
		public  void order_computerDesktopPrd()  {
	   
			WebElement  element1 = driver.findElement(By.xpath("//div[@class='header-menu']/ul[@class='top-menu']/li[2]/a"));
			Actions obj  =new Actions(driver);
			obj.moveToElement(element1);
			
			Reporter.log("Computer Desktop Product   successfully", true);
		}
		
		@AfterMethod
		public  void logout() {
			Reporter.log("log out successfully", true);
		}
		
		@AfterClass
		public void browserTermination() {
			driver.close();
			Reporter.log("browser close successfully", true);
		}
}


