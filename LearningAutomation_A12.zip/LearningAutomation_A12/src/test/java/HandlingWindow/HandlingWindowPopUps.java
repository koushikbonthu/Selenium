package HandlingWindow;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class HandlingWindowPopUps {

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		// Launch the browser
		WebDriver driver = new EdgeDriver();

		// Maximize the browser
		driver.manage().window().maximize();

		// Navigate to Demo web shop
		driver.navigate().to(new URL("https://in.indeed.com/"));

		// verify the page
		System.out.println("Title is: " + driver.getTitle());

		// Locate signin Link
		WebElement signin = driver.findElement(By.partialLinkText("Sign in"));

		// Click on Sign In link
		signin.click();

		// Click on Continue_with_apple button
		WebElement Continue_with_apple = driver.findElement(By.cssSelector("#apple-signin-button"));

		// Click on Continue_with_apple button
		Continue_with_apple.click();

		Thread.sleep(5);
		// Verify The window----> Identify Parent-ID and AllWindow-ID's
		String parent_id = driver.getWindowHandle();
		System.out.println(parent_id);

		Set<String> allWindow_id = driver.getWindowHandles();
		System.out.println(allWindow_id);

		// Switch the control using for-each
		for (String window : allWindow_id) {
			driver.switchTo().window(window);

			if (window.equals(parent_id)) {
				System.out.println("Parent Window");
			} else {
				System.out.println("Child Window");
				// Locate Email textfield
				WebElement email = driver.findElement(By.cssSelector("#account_name_text_field"));
				// Enter the data in email text field
				email.sendKeys("seleniumbatchA12@gmail.com");
				System.out.println("Data entered successfully");
				// Close child window
				driver.close();
			}
			// driver.close();
		}
		for (String window : allWindow_id) {
			driver.switchTo().window(window);

			if (window.equals(parent_id)) {
				// Close Parent Window
				driver.close();
			}
		}

		// Close the browser
		// driver.quit();

	}

}
