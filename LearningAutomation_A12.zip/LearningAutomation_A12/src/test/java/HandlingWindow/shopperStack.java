package HandlingWindow;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class shopperStack {

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		// Launch the browser
		WebDriver driver = new ChromeDriver();

		// Maximize the browser
		driver.manage().window().maximize();

		// Navigate to Demo web shop
		driver.navigate().to(new URL("https://www.shoppersstack.com/"));

		// Wait
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

		// verify the page
		System.out.println("Title is: " + driver.getTitle());

		// Locate the product
		WebElement product = driver.findElement(By.xpath("//span[text()='FOREVER21']"));

		// Click on the product
		product.click();

		// Scroll to view
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,0)");

		// Identify compare button
		WebElement compare = driver.findElement(By.cssSelector("#compare"));

		// click on compare button
		compare.click();

		// Verify The window----> Identify Parent-ID and AllWindow-ID's
		String parent_id = driver.getWindowHandle();
		System.out.println(parent_id);

		Set<String> allWindow_id = driver.getWindowHandles();
		System.out.println(allWindow_id);

		// Switch the control using for-each
		for (String window : allWindow_id) {
			driver.switchTo().window(window);

			if (window.equals(parent_id)) {
				System.out.println("Parent Window");
			} else {
				System.out.println("Child Window");
				// Close child window
				driver.close();
			}
		}
		for (String window : allWindow_id) {
			driver.switchTo().window(window);

			if (window.equals(parent_id)) {
				// Close Parent Window
				driver.close();
			}
		}

	}

}
