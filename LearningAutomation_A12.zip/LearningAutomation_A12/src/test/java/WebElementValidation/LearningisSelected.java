package WebElementValidation;

import java.lang.reflect.Executable;
import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class LearningisSelected {

	public static void main(String[] args) throws MalformedURLException {
				//Launch the browser
				WebDriver driver = new EdgeDriver();
				
				//Maximize the browser
				driver.manage().window().maximize();
				
				//Navigate to URL
				driver.navigate().to(new URL("https://demowebshop.tricentis.com/"));
				
				//Verify the page
				System.out.println("Title is: "+driver.getTitle());
				
				//Locate the element (Excellent radio button) and store it
				WebElement excellent = driver.findElement(By.cssSelector("#pollanswers-1"));
				
				//Validate the element if selected or not
				if(excellent.isSelected())
				{
					System.out.println("Radio button is selected");
				}
				else
				{
					System.out.println("Radio button is not selected");
				}
				
				//Click on the element
				excellent.click();
				
				//Validate the element again if selected or not
				if(excellent.isSelected())
				{
					System.out.println("Radio button is selected");
				}
				else
				{
					System.out.println("Radio button is not selected");
				}
				
				
				//Close the browser
				driver.quit();	
	}

}
