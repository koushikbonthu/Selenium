package WebElementValidation;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearningIsDisplayedAndIsEnabled {

	public static void main(String[] args) throws MalformedURLException {
		
		//Launch Browser
		WebDriver driver = new ChromeDriver();
		
		//Navigate to URL
		driver.navigate().to(new URL("https://www.saucedemo.com/"));
		
		//Locate username Textfield
		WebElement usernametextfield = driver.findElement(By.xpath("(//input)[1]"));
		
		//Validate element
		if (usernametextfield.isDisplayed() && usernametextfield.isEnabled()) {
			System.out.println("Username text field is displayed and enabled");
		} else {
			System.out.println("Username text field is not displayed or not enabled");
		}
		driver.quit();
	}

}
