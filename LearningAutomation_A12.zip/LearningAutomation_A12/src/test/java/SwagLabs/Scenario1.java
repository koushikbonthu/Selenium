package SwagLabs;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

public class Scenario1 {

	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		//Take input from user Nth product to view
		Scanner sc= new Scanner(System.in);
		/*System.out.println("Enter Number of the product between 1-6");
		int prodNum= sc.nextInt();*/
		System.out.println("Enter Name of the product ");
		String prodName= sc.nextLine();
		//launch browser
		WebDriver driver = new EdgeDriver();
		//Maximize browser
		driver.manage().window().maximize();
		//Navigate to application
		driver.navigate().to (new URL("https://www.saucedemo.com/"));
		//Locate Username textfield
		WebElement username= driver.findElement(By.xpath("//input[@id='user-name']"));
		//Validate element
		if (username.isDisplayed() && username.isEnabled()) {
		System.out.println("Username text field is displayed and enabled");
		//Enter username
		username.sendKeys("standard_user");
		} else {
		System.out.println("Username text field is not displayed or not enabled");
		}
		
		//Locate password textfield
		WebElement password= driver.findElement(By.xpath("//input[@id='password']"));
		//Validate element
		if (password.isDisplayed() && password.isEnabled()) {
		System.out.println("Password text field is displayed and enabled");
		//Enter password
		password.sendKeys("secret_sauce");
		} else {
		System.out.println("Password text field is not displayed or not enabled");
		}
		
		//Locate login button
		WebElement login= driver.findElement(By.xpath("//input[@class='submit-button btn_action']"));
		//Validate element
		if (login.isDisplayed() && login.isEnabled()) {
		System.out.println("login Button is displayed and enabled");
		login.click();
		} else {
		System.out.println("login Button is not displayed or not enabled");
		}
		
		
		Thread.sleep(5);
		//Locate product from input
		/*
		WebElement product= driver.findElement(By.xpath("//div[text()='Sauce Labs Backpack']"));
		WebElement product2= driver.findElement(By.xpath("//div[text()='Sauce Labs Bike Light']"));
		WebElement product3= driver.findElement(By.xpath("//div[text()='Sauce Labs Bolt T-Shirt']"));
		WebElement product4= driver.findElement(By.xpath("//div[text()='Sauce Labs Fleece Jacket']"));
		WebElement product5= driver.findElement(By.xpath("//div[text()='Sauce Labs Onesie']"));
		WebElement product6= driver.findElement(By.xpath("//div[text()='Test.allTheThings() T-Shirt (Red)']"));
		*/
		WebElement product= driver.findElement(By.xpath("//div[text()='"+prodName+"']"));

		//Validate element
		if (product.isDisplayed() && product.isEnabled()) {
		System.out.println(prodName+" is displayed and enabled");
		//Click on login button
		product.click();
		} else {
		System.out.println(prodName+" is not displayed or not enabled");
		}
		/*
		//Click on the product
		if (prodName==1) {
			product.click();
		}
		else if (prodName==2) {
			product2.click();
		}
		else if (prodName==3) {
			product3.click();
		}
		else if (prodName==4) {
			product4.click();
		}
		else if (prodName==5) {
			product5.click();
		}
		else if (prodName==6) {
			product6.click();
		}
		else {
			System.out.println("Enter 1-6 numbers");
		}
			*/
		/*
		switch (prodNum) {
		case 1:
			product.click();
			break;
		case 2:
			product2.click();
			break;
		case 3:
			product3.click();
			break;
		case 4:
			product4.click();
			break;
		case 5:
			product5.click();
			break;
		case 6:
			product6.click();
			break;

		default:
			break;
		}
		*/
		
		//Fetch product Name
		WebElement name= driver.findElement(By.xpath("//div[@data-test='inventory-item-name']"));
		//Validate element
				if (name.isDisplayed() && name.isEnabled()) {
				System.out.println(prodName+" Name is displayed and enabled");
				} else {
				System.out.println(prodName+" Name is not displayed or not enabled");
				}
		// Fetch product details
		WebElement details= driver.findElement(By.xpath("//div[@data-test='inventory-item-desc']"));
		//Validate element
				if (details.isDisplayed() && details.isEnabled()) {
				System.out.println(prodName+" Details is displayed and enabled");
				} else {
				System.out.println(prodName+"Details is not displayed or not enabled");
				}
		//Fetch product price
		WebElement price= driver.findElement(By.xpath("//div[@data-test='inventory-item-price']"));
		//Validate element
				if (price.isDisplayed() && price.isEnabled()) {
				System.out.println(prodName+" Price is displayed and enabled");
				} else {
				System.out.println(prodName+" Price is not displayed or not enabled");
				}
		
		//Print Product Details
		System.out.println("Name is: "+name.getText());
		System.out.println("Description is: "+details.getText());
		System.out.println("Price is: "+price.getText());
		
		//Close the browser
		driver.close();
		sc.close();
		
	}
}
