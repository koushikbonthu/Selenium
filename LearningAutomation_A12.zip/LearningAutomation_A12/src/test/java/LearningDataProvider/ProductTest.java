package LearningDataProvider;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ProductTest {

	@DataProvider()
	public Object[][] batchdata() {
		
		Object[][] data = new Object[3][3];
		data[0][0] = 3;
		data[0][1] = "User1";
		data[0][2] = true;
		
		data[1][0] = 6;
		data[1][1] = "User2";
		data[1][2] = false;
		
		data[2][0] = 36;
		data[2][1] = "User3";
		data[2][2] = true;
		
		
		return data;
	}
	
	@Test(dataProvider = "batchdata")
	public void DemoTest(int batchcode,String name, boolean status) {
		
		System.out.println(batchcode);
		System.out.println(name);
		System.out.println(status);
	}
	
	
}
