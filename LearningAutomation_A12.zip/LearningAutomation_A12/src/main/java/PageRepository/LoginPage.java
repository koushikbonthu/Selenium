package PageRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

		// Web-element identification and declaration
			@FindBy(id = "user-name")
			private WebElement usernameTextfield;
		
			@FindBy(id = "password")
			private WebElement passwordTextfield;
		
			@FindBy(id = "login-button")
			private WebElement LoginButton;
		
		// Web-element intialization
			public LoginPage(WebDriver driver) {
				PageFactory.initElements(driver, this);
			}
		
		// Web-eleemnt utilization
		
			public WebElement getusernameTextfield() {
				return usernameTextfield;
		
			}
		
			public WebElement getpasswordTextfield() {
				return passwordTextfield;
		
			}
		
			public WebElement getLoginButton() {
				return LoginButton;
		
			}

}
