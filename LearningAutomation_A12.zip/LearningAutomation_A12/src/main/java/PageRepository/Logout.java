package PageRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Logout {

	@FindBy(id = "react-burger-menu-btn")
	private WebElement menu;

	@FindBy(id = "logout_sidebar_link")
	private WebElement logoutBtn;

	public Logout(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public WebElement getmenu() {
		return menu;

	}

	public WebElement getlogoutBtn() {
		return logoutBtn;

	}

}
