package PageRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DWSLoginPage {
	// Web-element identification and declaration

	@FindBy(linkText = "Log in")
	private WebElement loginlink;

	@FindBy(id = "Email")
	private WebElement email;

	@FindBy(id = "Password")
	private WebElement password;

	@FindBy(xpath = "//input[@value='Log in']")
	private WebElement LoginButton;

	// Web-element intialization
	public DWSLoginPage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	// Web-eleemnt utilization

	public WebElement getloginlink() {
		return loginlink;
	}

	public WebElement getemail() {
		return email;

	}

	public WebElement getpassword() {
		return password;

	}

	public WebElement getLoginButton() {
		return LoginButton;

	}
}
