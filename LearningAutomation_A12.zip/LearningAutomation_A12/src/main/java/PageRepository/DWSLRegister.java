package PageRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DWSLRegister {

	// Web-element identification and declaration

	@FindBy(id = "gender-male")
	private WebElement male;

	@FindBy(id = "gender-female")
	private WebElement female;

	@FindBy(id = "FirstName")
	private WebElement fname;

	@FindBy(id = "LastName")
	private WebElement lname;

	@FindBy(id = "Email")
	private WebElement email;

	@FindBy(id = "Password")
	private WebElement pwd;

	@FindBy(id = "ConfirmPassword")
	private WebElement cpwd;

	@FindBy(id = "register-button")
	private WebElement rBtn;

	// Web-element intialization
	public DWSLRegister(WebDriver driver) {
		PageFactory.initElements(driver, this);

	}

	// Web-eleemnt utilization

	public WebElement getmale() {
		return male;

	}

	public WebElement getfemale() {
		return female;

	}

	public WebElement getFirstName() {
		return fname;

	}

	public WebElement getLastName() {
		return lname;

	}

	public WebElement getEmail() {
		return email;

	}

	public WebElement getPassword() {
		return pwd;

	}

	public WebElement getConfirmPassword() {
		return cpwd;

	}

	public WebElement getRegisterButton() {
		return rBtn;

	}

}