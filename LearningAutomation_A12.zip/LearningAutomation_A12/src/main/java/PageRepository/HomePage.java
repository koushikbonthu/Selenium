package PageRepository;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

	@FindBy(xpath = "//div[text()='Sauce Labs Backpack']")
	private WebElement product1;

	@FindBy(xpath = "//div[@class='inventory_item_name ']")
	private List<WebElement> product;

	@FindBy(xpath = "//img[@alt='Go back']")
	private WebElement back;

	@FindBy(id = "add-to-cart")
	private WebElement aadToCart;

	@FindBy(xpath = "//a[@class='shopping_cart_link']")
	private WebElement cartIcon;

	// Web-element intialization
	public HomePage(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public WebElement getproduct1() {
		return product1;

	}

	public List<WebElement> getproducts() {

		return product;

	}

	public WebElement getBack() {
		return back;
	}

	public WebElement getaddTocart() {
		return aadToCart;

	}

	public WebElement getcartIcon() {
		return cartIcon;

	}

}
