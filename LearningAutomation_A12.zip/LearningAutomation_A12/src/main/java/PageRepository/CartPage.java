package PageRepository;

public class CartPage {

}
